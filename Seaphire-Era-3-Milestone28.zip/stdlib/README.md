# Seaphire Era 3 Standard Library

The standard library is organized by package-aware namespaces:

- `std::core::*` — core scalar/string helpers
- `std::io::*` — basic output helpers
- `std::path::*` — non-allocating path/string inspection
- `std::process::*` — native process/runtime utilities

Source files remain `.inu`. The `std` namespace is resolved locally by the
compiler wrapper and never requires a network registry.
