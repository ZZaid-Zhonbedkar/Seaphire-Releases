#include <stdint.h>
int64_t cphire_add_i64(int64_t a, int64_t b) { return a + b; }
