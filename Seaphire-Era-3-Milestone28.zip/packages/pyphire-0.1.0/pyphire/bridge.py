from __future__ import annotations
import json, subprocess, sys
from typing import Any, Dict, Optional

PROTOCOL = "json-lines-v1"

def protocol_version() -> str:
    return PROTOCOL

class Bridge:
    """Persistent Python worker using JSON-lines requests."""
    def __init__(self, worker: Optional[str] = None):
        self.worker = worker or str(__import__('pathlib').Path(__file__).with_name('worker.py'))
        self.proc = subprocess.Popen([sys.executable, self.worker], stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE, text=True, bufsize=1)
    def call(self, function: str, *args: Any, **kwargs: Any) -> Any:
        if not self.proc.stdin or not self.proc.stdout: raise RuntimeError('pyphire worker unavailable')
        req = {'protocol': PROTOCOL, 'op': 'call', 'function': function, 'args': list(args), 'kwargs': kwargs}
        self.proc.stdin.write(json.dumps(req)+'\n'); self.proc.stdin.flush()
        line = self.proc.stdout.readline()
        if not line: raise RuntimeError('pyphire worker exited')
        res=json.loads(line)
        if not res.get('ok'): raise RuntimeError(res.get('error','pyphire call failed'))
        return res.get('result')
    def close(self):
        if self.proc.stdin:
            self.proc.stdin.write(json.dumps({'protocol':PROTOCOL,'op':'close'})+'\n'); self.proc.stdin.flush()
        self.proc.terminate(); self.proc.wait(timeout=2)
    def __enter__(self): return self
    def __exit__(self,*exc): self.close()

def call(function: str, *args: Any, **kwargs: Any) -> Any:
    with Bridge() as b: return b.call(function,*args,**kwargs)

def run_python(source: str, payload: Optional[Dict[str,Any]]=None) -> Any:
    """Execute a tiny Python function named `main(payload)` in a worker."""
    import tempfile, os
    code = source + "\n"
    with tempfile.NamedTemporaryFile('w',suffix='.py',delete=False) as f:
        f.write(code); path=f.name
    try:
        return _call_script(path, payload or {})
    finally: os.unlink(path)

def _call_script(path, payload):
    env={'PYTHONPATH':str(__import__('pathlib').Path(path).parent)}
    req=json.dumps({'protocol':PROTOCOL,'op':'script','path':path,'payload':payload})
    p=subprocess.run([sys.executable, str(__import__('pathlib').Path(__file__).with_name('worker.py'))],input=req+'\n',text=True,capture_output=True,env={**__import__('os').environ,**env})
    if p.returncode: raise RuntimeError(p.stderr.strip() or 'pyphire worker failed')
    res=json.loads(p.stdout.splitlines()[-1])
    if not res.get('ok'): raise RuntimeError(res.get('error','script failed'))
    return res.get('result')
