import importlib, json, os, sys, traceback

def main(req):
    if req.get('protocol') != 'json-lines-v1': return {'ok':False,'error':'unsupported pyphire protocol'}
    op=req.get('op')
    if op=='close': return {'ok':True,'result':None}
    try:
        if op=='call':
            modname, _, attr=req['function'].rpartition('.')
            if not modname: raise ValueError('function must be module.function')
            fn=getattr(importlib.import_module(modname),attr)
            return {'ok':True,'result':fn(*req.get('args',[]),**req.get('kwargs',{}))}
        if op=='script':
            ns={};
            with open(req['path'],encoding='utf-8') as f: code=compile(f.read(),req['path'],'exec')
            exec(code,ns,ns); fn=ns.get('main')
            if not callable(fn): raise ValueError('script must define main(payload)')
            return {'ok':True,'result':fn(req.get('payload',{}))}
        raise ValueError('unknown pyphire operation')
    except Exception as e:
        return {'ok':False,'error':f'{type(e).__name__}: {e}'}

for line in sys.stdin:
    if not line.strip(): continue
    print(json.dumps(main(json.loads(line))),flush=True)
