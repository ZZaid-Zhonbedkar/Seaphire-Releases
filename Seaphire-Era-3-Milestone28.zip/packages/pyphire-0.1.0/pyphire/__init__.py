"""Pyphire: Python interoperability for Seaphire.

Pyphire uses a small JSON-lines protocol so Seaphire programs can exchange
structured values with Python without making Python part of the Seaphire ABI.
"""
from .bridge import Bridge, call, run_python, protocol_version
__all__ = ["Bridge", "call", "run_python", "protocol_version"]
