# Pyphire

Pyphire is Seaphire's Python interoperability library. It is intentionally a
library boundary, not a Python clone: Seaphire stays compiled/native while
Python is connected through a small JSON-lines protocol.

```python
from pyphire import call
print(call("math.sqrt", 81))
```

The protocol is `json-lines-v1`. The design keeps the Seaphire ABI independent
from the CPython ABI and leaves room for a future native CPython extension.
