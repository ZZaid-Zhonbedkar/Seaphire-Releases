# Pyphire API

- `pyphire.protocol_version()` -> protocol identifier
- `pyphire.call("module.function", *args, **kwargs)` -> JSON-compatible result
- `pyphire.Bridge()` -> persistent worker
- `pyphire.run_python(source, payload)` -> executes `main(payload)` in a worker

Pyphire is designed as a language-connection library, analogous in role to a
language's standard C interoperability layer, but specialized for Python.
