#ifndef CPHIRE_H
#define CPHIRE_H

/* CPhire 0.1: stable C-facing ABI helpers for Seaphire.
 * Seaphire i64 maps to C int64_t on the hosted x86-64 System V target.
 */
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

int64_t cphire_add_i64(int64_t a, int64_t b);
int64_t cphire_mul_i64(int64_t a, int64_t b);

#ifdef __cplusplus
}
#endif

#endif
