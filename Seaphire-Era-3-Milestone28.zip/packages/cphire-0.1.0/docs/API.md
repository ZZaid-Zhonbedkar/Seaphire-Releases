# CPhire API

CPhire is Seaphire's native C interoperability layer.

## ABI

- Target: x86-64 System V
- Seaphire `int`/`i64` maps to C `int64_t`
- C functions are declared in Seaphire with `EXTERN FUNC`
- C source/object files are linked by `sea c build`

Example:

```text
EXTERN FUNC c_add(A: int, B: int) -> int;

FUNC main() -> int {
    int value = c_add(40, 2)
    PRINT value
    RET value
}
```

Then:

```text
sea c build src/main.inu native/add.c -o build/app
```

CPhire 0.1 intentionally starts with scalar integer ABI coverage. Pointer,
string, struct, callback, shared-library and platform-specific ABI layers are
future milestones.
