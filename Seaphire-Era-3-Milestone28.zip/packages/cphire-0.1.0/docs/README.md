# CPhire

CPhire connects Seaphire to native C libraries through the platform ABI.
It is the native counterpart to Pyphire: Pyphire is a language-process bridge,
while CPhire is a direct compiled ABI bridge.
