# Seaphire Era 3 — Milestone 27

**Era 2 Delta is frozen. Era 3 has begun.**

Milestone 23 starts the native Seaphire package ecosystem.

- Source remains `.inu`.
- Project manifests remain `seaphireinit.toml`.
- Packages remain `.inupkg`.
- `.inupkg` now carries `inupkg.json` metadata.
- Local registries can be indexed and packages installed offline.
- `seaphire.lock` records resolved package versions.

Example:

```text
seaphire package index .seaphire-registry
seaphire package install hello-lib .seaphire-registry
seaphire package list
```

Network registries and publishing come later in Era 3.

## Era 3 — Milestone 24

Package dependencies now resolve deterministically from the local registry, including transitive dependencies and semver constraints. `seaphire.lock` records the resolved graph. Syntax v2 projects can import package symbols with `IMPORT package::symbol` or `IMPORT package::*`; imports are expanded by the native frontend before normal lowering.

Commands:

```text
seaphire package resolve [registry-dir]
seaphire package install <name> [registry-dir]
```

## Era 3 — Milestone 25

Milestone 25 adds package publishing and cryptographic authenticity:

- Ed25519 package signatures
- SHA-256 package digests
- publisher key IDs
- local registry publication
- detached `.inupkg.sig` signatures
- package signature verification and tamper detection

Example:

```text
seaphire package keygen publisher.pem
seaphire package sign target/package/example-1.0.0.inupkg publisher.pem
seaphire package verify target/package/example-1.0.0.inupkg target/package/example-1.0.0.inupkg.sig publisher.pem.pub.pem
seaphire package publish target/package/example-1.0.0.inupkg .seaphire-registry publisher.pem
```

## Era 3 — Milestone 26

Milestone 26 expands the standard library and gives it a first-class local `std` namespace.

Standard-library modules:

- `std::core` — scalar and string helpers
- `std::io` — basic output helpers
- `std::path` — non-allocating path inspection
- `std::process` — process ID, monotonic runtime clock access, and process exit

Example:

```text
IMPORT std::core::core_min
IMPORT std::path::path_len
IMPORT std::process::process_id
```

Native runtime primitives introduced in this milestone:

```text
runtime_process_id()
runtime_time_ms()
runtime_exit(code)
```

## Era 3 — Milestone 27

Milestone 27 introduces the formal `sea` developer/package-manager command, a formatter, linter, symbol indexer, and the first language-connection library: **Pyphire**.

```text
sea install pyphire
sea search pyphire
sea info pyphire
sea fmt src/main.inu
sea lint src/main.inu
sea symbols src/main.inu
```

Pyphire connects Python and Seaphire through the `json-lines-v1` protocol. It is
intended as an interoperability library rather than a Python clone.

## Era 3 — Milestone 28

Milestone 28 adds **CPhire**, Seaphire's direct native C interoperability layer.
The native backend now supports `EXTERN FUNC` declarations, and the linker can
accept C object files and libraries. The `sea c build` command compiles C sources
and links them with a Seaphire native executable.

Example:

```text
EXTERN FUNC c_add(A: int, B: int) -> int;

FUNC main() -> int {
    int value = c_add(40, 2)
    PRINT value
    RET value
}
```

Build with:

```text
sea c build src/main.inu native/add.c -o build/app
```

CPhire 0.1 uses the hosted x86-64 System V ABI and maps Seaphire `int`/`i64`
to C `int64_t`. Pointer, string, struct, callback, shared-library and
platform-specific ABI work remains future expansion.
