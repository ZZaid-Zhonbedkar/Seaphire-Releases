# Kernel memory subsystem

This directory defines the intended safe/unsafe split for the physical and virtual memory
subsystems.

`unsafe` code is restricted to page-table writes, physical-frame discovery and architecture
instructions. Higher layers consume typed handles rather than arbitrary addresses.
