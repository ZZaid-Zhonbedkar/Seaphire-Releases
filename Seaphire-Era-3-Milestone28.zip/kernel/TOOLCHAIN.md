# Native kernel toolchain

The Seaphire project manager does not use Cargo. The native OS pipeline is intentionally
small and explicit:

1. `seaphirec` performs lexical, syntactic and safety analysis.
2. The future native backend lowers typed IR to target assembly/object code.
3. `kernel/linker.ld` fixes the freestanding image layout.
4. A bootloader (initially Multiboot2/UEFI) loads the kernel.
5. Architecture code enters `kernel_main`.

The current repository ships the ABI and linker scaffolding plus an x86_64 entry emitter.
It does not claim a complete native compiler until code generation is implemented.
