/* Canonical boot entry is emitted by seaphirec for now. */
.section .note.GNU-stack,"",@progbits
