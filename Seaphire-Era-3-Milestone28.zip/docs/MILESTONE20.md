# Milestone 20 — Generic Structs

Milestone 20 extends compile-time generics from scalar functions to aggregate
struct definitions.

## Syntax

```text
STRUCT Pair<T> {
    left: T
    right: T
}

FUNC main() -> int {
    Pair<int> p = { left: 19, right: 23 }
    PRINT p.left
    PRINT p.right
    RET p.left + p.right
}
```

Generic structs are specialized at compile time. `Pair<int>` becomes an
ordinary native aggregate (`Pair_i64`) before the existing aggregate layout
pass runs. There is no runtime generic metadata or dispatch.

For this Era 2 milestone, generic struct parameters may be instantiated with
`int`/`i64`. The aggregate backend therefore keeps its existing 8-byte field
layout and ownership rules.
