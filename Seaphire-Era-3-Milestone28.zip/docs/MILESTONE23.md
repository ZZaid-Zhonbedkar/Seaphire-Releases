# Milestone 23 — Era 3 Package Ecosystem Seed

Era 2 Delta is frozen. Milestone 23 begins Era 3 with a native package workflow around `.inupkg`.

## Added

- `inupkg.json` package metadata inside generated archives.
- Local package registry indexing with `seaphire package index`.
- Package installation with `seaphire package install`.
- Deterministic `seaphire.lock` dependency records.
- `seaphire package list` for installed packages.
- Era 3 package manifests use `edition = "era3"`.
- Sample `hello-lib` package.

This is intentionally a local/offline ecosystem seed. Network registries, cryptographic signing, publishing, and semantic version solving are planned for later Era 3 milestones.

## Command surface

```text
seaphire package check
seaphire package build [output-dir]
seaphire package index [registry-dir]
seaphire package install <name> [registry-dir]
seaphire package list
```

The registry is deliberately filesystem-based in this milestone so the workflow is testable without network access.
