# Milestone 16 — Seaphire Syntax v2 + Arrays

Milestone 16 establishes the intended middle ground for Seaphire's surface language: C-like blocks and function declarations combined with assembly-inspired instructions.

## Function forms

```text
FUNC add(A, B) -> int {
    int result = A
    ADD result, B
    RET result
}
```

A shorter return-type form is also accepted:

```text
int add(A, B) {
    ADD A, B
    RET A
}
```

## Statements

Inside `{ ... }` blocks, Seaphire v2 accepts familiar structure while retaining opcode-style operations:

- `MOV A, B`
- `ADD A, B`
- `SUB A, B`
- `MUL A, B`
- `DIV A, B`
- `PRINT value`
- `RET value`
- `IF condition { ... } ELSE { ... }`
- `LOOP condition { ... }`

## Arrays

The first native array surface is an owned integer slice represented by the existing checked `slice_i64` runtime:

```text
FUNC main() -> int {
    int values[] = [10, 20, 12]
    values[1] = 22
    int total = values[0]
    ADD total, values[1]
    ADD total, values[2]
    PRINT total
    RET total
}
```

Sized arrays are also accepted:

```text
int values[3]
```

Array reads and writes lower to checked `slice_at` / `slice_set` operations, so out-of-bounds access remains a runtime error rather than unchecked memory access.

## Design goal

Seaphire is deliberately **not Rust syntax** and deliberately **not raw assembly**. The target is a quirky, readable, assembly-inspired systems language with structured blocks and a serious native compiler underneath.

The `.inu` extension remains canonical.
