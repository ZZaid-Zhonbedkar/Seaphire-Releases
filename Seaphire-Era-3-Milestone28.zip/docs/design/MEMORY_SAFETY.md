# Seaphire Era 2 Delta — Memory Safety

## Goals

Seaphire is intended to be useful below the OS boundary without making every program an
`unsafe` program. The safety model is inspired by Rust but is designed around Seaphire's
small syntax.

### Ownership

A future owned heap value is written `box T`. Moving an owned value transfers its unique
owner. The source binding becomes unusable after the move.

### Borrowing

Shared references will use `&T`; exclusive references will use `&mut T`. The rules are:

- many shared borrows OR one exclusive borrow;
- references cannot outlive their owner;
- mutation is forbidden while any reference is active;
- no null reference in safe code.

### Unsafe boundary

Hardware registers, physical addresses, interrupt tables, DMA buffers and inline assembly
are inherently outside ordinary safe memory rules. They will require an explicit `unsafe`
boundary and a small audited API.

### Kernel mode

The kernel may use unsafe primitives, but safe Seaphire code can call them only through
checked wrappers that encode size, alignment and ownership requirements.
