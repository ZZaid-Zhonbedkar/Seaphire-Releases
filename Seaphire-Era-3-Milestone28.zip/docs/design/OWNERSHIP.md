# Ownership and borrowing roadmap

Seaphire's goal is not to copy Rust syntax blindly. The invariant is more important than the
spelling: safe code must have one clear owner for mutable state and must never observe a
reference after its owner is invalid.

## Planned core forms

```inu
let page: box Page = box Page::new();
let view: &Page = &page;
let edit: &mut Page = &mut page;
```

The parser/type system will eventually lower these to an explicit region/borrow IR. The
current Era 2 safety pass deliberately starts with the simpler rules that are already
provable in the existing AST: immutable-by-default bindings, explicit mutation, exact type
checking and conservative alias restrictions.

## Milestone 7 native ownership rules

The native backend now distinguishes shared `&i64` from exclusive `&mut i64` references.
The current checker uses a deliberately conservative function-wide lifetime: once a local is borrowed,
that local cannot be assigned again until the function ends. Shared borrows may coexist; mutable borrows
are exclusive and conflict with both shared and other mutable borrows. This is an intermediate model,
not the final region-based borrow checker.
