# Milestone 26 — Standard Library Expansion

Milestone 26 expands Era 3's standard library and makes it package-aware through a reserved local `std` namespace.

## Standard library layout

- `stdlib/core/` — core scalar/string helpers
- `stdlib/io/` — basic I/O helpers
- `stdlib/path/` — non-allocating path inspection
- `stdlib/process/` — process/runtime wrappers

## Imports

The native import resolver now accepts:

```text
IMPORT std::core::core_min
IMPORT std::path::path_len
IMPORT std::process::process_id
```

Wildcard imports are also supported:

```text
IMPORT std::core::*
```

The resolver reads `stdlib/` directly, so the standard library does not require registry access or network access.

## Native runtime utilities

The native backend now exposes stable compiler/runtime boundaries for:

- `runtime_process_id()`
- `runtime_time_ms()`
- `runtime_exit(code)`

`runtime_time_ms()` returns wall-clock milliseconds from the host clock source. These are deliberately small primitives; higher-level process and OS abstractions remain future Era 3 work.

## Package metadata

`.inupkg` metadata format is upgraded to format 3 and records the standard-library namespace/root alongside normal dependency metadata.

## Verification

The M26 workflow verifies:

- stdlib package metadata
- `std::module::symbol` imports
- string-parameter support in the native ABI
- path/string helpers
- process/runtime utilities
- existing native regression tests
