# Seaphire Era 2 Delta — Milestone 8

## Borrow regions + reference parameters

Milestone 8 turns references into callable typed values and adds mutation through `&mut` references.

### New language surface

```inu
fn bump(r: &mut i64) -> i64 {
    *r = *r + 1;
    return *r;
}

fn main() -> i64 {
    let mut value: i64 = 41;
    return bump(&mut value);
}
```

- Function parameters may be `i64`, `&i64`, or `&mut i64`.
- Calls are checked against parameter types; `&mut i64` may be passed where `&i64` is expected.
- Mutable dereference assignment (`*r = value`) is supported.
- Stores through `&i64` are rejected by the typed IR verifier.
- `&mut` can only borrow a mutable local.
- Borrow activity is scoped to the containing lexical block instead of the whole function.
- References can be forwarded through typed function parameters.
- References still cannot be returned; heap ownership and general slices remain future work.

