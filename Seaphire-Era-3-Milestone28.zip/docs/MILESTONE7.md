# Seaphire Era 2 Delta — Milestone 7

## Ownership + exclusive mutable borrowing

Milestone 7 introduces the first ownership-aware borrow rules in the native backend.

### New language surface

```inu
fn main() -> i64 {
    let mut value: i64 = 41;
    let r: &mut i64 = &mut value;
    println *r;
    return *r;
}
```

- `&T` creates a shared borrow.
- `&mut T` creates an exclusive mutable borrow.
- A mutable borrow requires a mutable source local.
- A local cannot be assigned while it has an active borrow.
- Two mutable borrows of the same local are rejected.
- A mutable borrow cannot coexist with a shared borrow.
- Shared borrows may coexist.
- References remain local-only and cannot cross function boundaries.
- Borrow lifetimes are deliberately conservative: a borrow remains active for the containing function.

This milestone does not yet permit writing through a reference. That is reserved for the next borrow/lvalue milestone so the compiler can enforce exclusive access at the mutation site too.
