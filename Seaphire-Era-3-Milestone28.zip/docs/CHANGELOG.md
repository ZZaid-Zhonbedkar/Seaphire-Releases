## Milestone 19

- Added Syntax v2 generic functions.
- Added compile-time monomorphization.
- Added scalar `int`/`i64` generic instantiations and diagnostics.
- Added native generic tests.


## Milestone 18
- Added first-class tagged-union IR operations in the Syntax v2 frontend.
- Added exhaustive MATCH validation.
- Added tagged-union positive and negative tests.

## Milestone 21

- Added `[package]` and `[dependencies]` manifest sections.
- Added `seaphire package check` and `.inupkg` archive generation.
- Added the initial `stdlib/` source tree.

## Milestone 22 — Era 2 Delta complete

- Added final native conformance command.
- Added release/freeze tooling and release manifest generation.
- Added final Era 2 Delta conformance documentation.
- Declared `.inu`, Syntax v2, `seaphireinit.toml`, and `.inupkg` as frozen Era 2 Delta foundations.
