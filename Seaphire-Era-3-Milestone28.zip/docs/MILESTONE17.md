# Milestone 17 — Enums + Tagged Unions

Milestone 17 adds enums and the first tagged-value layer to **Seaphire Syntax v2**.

## Enum syntax

```text
ENUM Color {
    RED,
    GREEN,
    BLUE
}
```

Variants receive deterministic discriminants starting at `0`.

## Matching

```text
MATCH color {
    CASE RED:
        PRINT 10
    CASE GREEN:
        PRINT 20
    DEFAULT:
        PRINT 30
}
```

`MATCH` lowers to structured conditional control flow. A `DEFAULT` arm is supported as the safe fallback while the first-class exhaustiveness checker is developed.

## Tagged variants

Payload variants can be declared:

```text
ENUM Result {
    OK(int),
    ERR(int),
    EMPTY
}
```

Constructors such as `OK(42)` are represented by a temporary native tagged-value ABI:

```text
payload * 256 + discriminant
```

The low byte is the discriminant and the remaining value carries the payload. `CASE OK AS value:` binds the payload for the arm.

This is intentionally **intermediate ABI groundwork**, not the final representation. Milestone 18 will replace it with first-class tagged-union IR and explicit discriminant/payload layout.

## Safety / diagnostics

- Unknown variants are rejected.
- Duplicate variant names are rejected.
- Payload arity is checked.
- Payload bindings are scoped to their match arm internally, avoiding duplicate-local collisions.
- Existing ownership, references, arrays, functions, and native backend validation remain active.
