# Milestone 12 — Structs and User-Defined Types

Adds stack-owned user-defined structs with `i64` fields.

```inu
struct Point { x: i64; y: i64; }
fn main() -> i64 {
    let mut p: Point = { x: 10, y: 32 };
    p.x = p.x + 1;
    return p.y;
}
```

Implemented:
- struct declarations with typed `i64` fields
- struct literals in `let` declarations
- field reads and mutable field writes
- references to fields through existing `&i64` / `&mut i64`
- initial ownership-aware struct moves
- native x86-64 output

Current limits: fields are `i64` only; heap structs, nested aggregates, methods, generics, and first-class aggregate IR are future work.
