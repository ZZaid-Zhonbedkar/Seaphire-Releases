# Building the OS-level scaffold

From the project root:

```text
seaphire check src/main.inu
seaphire build --target x86_64-kernel
```

The second command emits `build/kernel/seaphire_kernel_entry.S` and `build/kernel/kernel.ld`.
These files form the freestanding ABI boundary. A full ELF/ISO pipeline will be added only
when Seaphire has a real native code generator and target layout engine.
