# Milestone 18 — First-Class Tagged-Union IR

Milestone 18 moves Seaphire enums and tagged unions behind an explicit intermediate representation boundary.

## Source model

- `ENUM` declares variants and deterministic discriminants.
- Variants may carry one payload.
- `MATCH` operates on the tagged value, not on a source-level integer encoding.
- `MATCH` must be exhaustive unless it contains `DEFAULT`.

## IR operations

The Syntax v2 frontend records first-class operations:

- `TAGGED_CONSTRUCT`
- `TAGGED_TAG`
- `TAGGED_PAYLOAD`

The current native i64 backend lowers these operations at the final boundary to its compact host representation. This keeps the existing ELF backend stable while removing the representation from the language semantics.

## Exhaustiveness

A `MATCH` without `DEFAULT` must mention every declared variant. Missing variants are reported as a frontend error.

Future work will give tagged unions a true aggregate layout in the native backend rather than the temporary compact lowering.
