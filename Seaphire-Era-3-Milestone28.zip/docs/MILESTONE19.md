# Milestone 19 — Generic Functions

Milestone 19 adds source-level generic functions to Seaphire Syntax v2.

## Syntax

```text
FUNC identity<T>(value: T) -> T {
    RET value
}

FUNC main() -> int {
    int result = identity<int>(42)
    PRINT result
    RET result
}
```

## Semantics

Generic functions are **monomorphized at compile time**. Each explicit type
instantiation gets a distinct internal function symbol, so the runtime has no
generic dispatch or type-erasure overhead.

The Era 2 native scalar ABI currently supports `int`/`i64` generic
instantiations. Aggregate generic layouts will be added after the native type
ABI grows enough to represent them directly.

Nested generic calls are expanded as well. Unsupported type arguments are a
compile-time error.
