# Milestone 27 — Toolchain, `sea`, and Pyphire

Era 3 now has a formal developer command named `sea`. It is the package manager
and project tool for Seaphire.

```text
sea init
sea build
sea run src/main.inu
sea check src/main.inu
sea fmt src/main.inu
sea lint src/main.inu
sea symbols src/main.inu
sea search pyphire
sea install pyphire
sea uninstall pyphire
```

## Pyphire

`pyphire` is Seaphire's Python interoperability package. It is not a Python
syntax clone. It provides a language-connection boundary, similar in purpose
to a C interoperability layer, using `json-lines-v1` so the native Seaphire ABI
stays independent from the CPython ABI.

Python API:

```python
from pyphire import call
print(call("math.sqrt", 81))
```

The package also contains a Seaphire-side contract:

```text
IMPORT pyphire::pyphire_api_version
```

Future milestones can replace the worker transport with an optional native
CPython extension without changing the package-level API contract.
