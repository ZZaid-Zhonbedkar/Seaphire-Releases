# Milestone 14 — Nested and Aggregate Structs

Milestone 14 gives Seaphire structs an explicit aggregate layout model instead of treating every struct as an unrelated collection of rewritten locals.

## Added

- nested user-defined structs
- recursive layout calculation with cycle rejection
- 8-byte field alignment and machine-word slots on the current x86-64 native ABI
- deterministic flattened field paths for nested aggregates
- nested struct literals such as `top_left: { x: 10, y: 20 }`
- nested field reads and mutable writes (`r.top_left.x`)
- heap aggregate backing storage sized from the computed layout
- aggregate ownership transfer with `move`
- owning `slice_i64` and `box_i64` fields in heap aggregates
- typed raw-pointer conversion intrinsics used internally by the aggregate lowering
- move semantics for owning heap fields: reading an owning field transfers it out and clears the aggregate slot
- automatic cleanup of aggregate-owned slice/box members followed by aggregate storage cleanup
- explicit generated layout metadata for diagnostics and future IR work

## Layout

The current native ABI uses one 8-byte machine-word slot per field. Nested structs are laid out in place. Therefore:

```text
struct Point { x: i64; y: i64; }
struct Rect  { top_left: Point; bottom_right: Point; }
```

has four 8-byte slots and a size of 32 bytes with 8-byte alignment.

This is the first aggregate-layout contract that later native backends can replace with target-specific ABI rules.

## Ownership

Heap aggregates own their backing allocation. If an aggregate owns a `slice_i64` or `box_i64` field, that field is represented as an owned pointer in its aggregate slot. Reading that field is a move: the slot is cleared so the extracted value and the aggregate cannot both free the same allocation.

Replacing an owning field first drops the old member and then stores the new owner.

## Current limits

- recursive/self-referential structs are rejected
- struct-return ABI is still future work
- aggregate references to heap fields are not yet first-class
- target-specific alignment/packing beyond the current 8-byte x86-64 ABI is future work
- the native backend remains host-linked, not freestanding
- the current aggregate implementation is a source/IR bridge; a fully target-independent aggregate IR is planned for a later backend pass
