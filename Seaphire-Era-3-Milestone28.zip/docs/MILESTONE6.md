# Seaphire Era 2 Delta — Milestone 6

## References + checked slice access

Milestone 6 extends the native backend toward Seaphire's memory-safety model.

### New language surface

```inu
fn main() -> i64 {
    let value: i64 = 42;
    let r: &i64 = &value;
    println *r;
    return *r;
}
```

- `&x` creates a non-null local reference to an `i64` local.
- `*r` performs a typed dereference.
- References are immutable through this milestone; there is no `&mut` yet.
- References cannot be used in arithmetic, returned from functions, or passed across a function call.
- Borrow targets must be known locals, giving the backend a conservative lifetime boundary.

### Checked slice access

The first bounded byte-slice primitive is available through:

```inu
println slice_len("seaphire");
println slice_at("seaphire", 2);
```

`slice_at` performs a runtime bounds check before loading a byte. An out-of-range index aborts instead of reading arbitrary memory. The current milestone intentionally restricts the primitive to string literals; general `&[T]` values are reserved for the next ownership/borrow milestone.

### IR / CFG safety

The verifier now understands reference values and checked-index instructions. Reference values cannot flow into numeric operations or native calls. Control-flow instructions remain explicit labels/jumps/branches, making it possible to validate branch targets before assembly emission.

### Still not implemented

- `&mut T` and exclusive borrowing
- general heap ownership / `box T`
- general `&[T]` slices
- slice values with pointer + length representation
- reference parameters
- borrow lifetime regions across nested scopes
- SSA phi nodes and register allocation
- freestanding bounds-failure runtime
