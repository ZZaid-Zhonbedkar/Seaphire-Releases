# Seaphire Era 2 Delta Language

Era 2 Delta uses `.inu` for every Seaphire source file.

## Design goals

- systems-first fixed-width types
- explicit mutability
- deterministic control flow
- small compiler surface
- a clear path to native code generation

## Core syntax

```inu
fn add(a: i64, b: i64) -> i64 {
    return a + b;
}

fn main() -> i64 {
    let mut x: i64 = 10;
    x = add(x, 32);
    println x;
    return 0;
}
```

## Types

`i32`, `i64`, `u32`, `u64`, `f64`, `bool`, `str`, and `unit` are the initial built-in types.

## Mutability

Bindings are immutable by default:

```inu
let answer: i64 = 42;
let mut counter: i64 = 0;
counter = counter + 1;
```

## Control flow

```inu
if ready { println "go"; } else { println "wait"; }
while counter < 10 { counter = counter + 1; }
```

## Tooling

The project manifest is `seaphireinit.toml`. The standard source extension is `.inu`.

## Safety baseline

Era 2 Delta treats `let` as immutable and requires `let mut` for reassignment. The compiler
runs a safety/type pass before the reference runtime. This is the first stage of the
ownership model; pointer/reference syntax is reserved for the native backend milestones.
