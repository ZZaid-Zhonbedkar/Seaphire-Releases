# Seaphire Surface Syntax

## Syntax v2

Seaphire uses structured braces for functions and control flow, while its operations retain an assembly-inspired `OPCODE OPERAND1, OPERAND2` flavor.

```text
FUNC add(A, B) -> int {
    int result = A
    ADD result, B
    RET result
}
```

Equivalent return-type shorthand:

```text
int add(A, B) {
    ADD A, B
    RET A
}
```

### Core operations

```text
MOV X, Y
ADD X, Y
SUB X, Y
MUL X, Y
DIV X, Y
PRINT X
RET X
```

### Control flow

```text
IF X > 10 {
    PRINT X
} ELSE {
    PRINT 0
}

LOOP X < 20 {
    ADD X, 1
}
```

### Arrays

```text
int values[] = [1, 2, 3]
values[1] = 7
PRINT values[1]
```

Arrays currently lower to the native checked `slice_i64` representation. Function-parameter arrays and richer aggregate syntax remain future work.

## Compatibility

The older Rust-shaped `fn main() -> i64 { ... }` syntax and the Milestone 15 OG `_VARS/_MAIN/_END` frontend remain compatibility paths while the v2 syntax becomes the preferred Seaphire style.

The language is intended to be understandable without Rust knowledge or AI assistance.

## Enums and tagged values

```text
ENUM Result {
    OK(int),
    ERR(int),
    EMPTY
}

MATCH state {
    CASE OK:
        PRINT 1
    DEFAULT:
        PRINT 0
}
```

## Enums and tagged unions

```text
ENUM Result {
    OK(int),
    ERR(int),
    EMPTY
}

FUNC main() -> int {
    int result = OK(42)
    MATCH result {
        CASE OK AS value:
            PRINT value
        DEFAULT:
            PRINT 0
    }
    RET result
}
```


## Generic functions (Milestone 19)

Seaphire supports source-level generic functions with explicit type arguments:

```text
FUNC identity<T>(value: T) -> T {
    RET value
}

FUNC main() -> int {
    int result = identity<int>(42)
    RET result
}
```

Generic functions are monomorphized at compile time. The current Era 2 native
scalar ABI accepts `int`/`i64` instantiations; unsupported type arguments are
rejected during frontend compilation.
