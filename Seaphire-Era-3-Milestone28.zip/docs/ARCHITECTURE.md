# Era 2 Delta architecture

```text
.inu source
   |
   v
lexer -> parser -> AST -> reference runtime
                         |
                         +--> future typed IR
                                  |
                                  +--> native backend
```

The `seaphire` command owns project operations. The current reference compiler is deliberately dependency-free and can be built with `rustc` directly.

Future systems layers should add pointers/references, structs, enums, explicit allocation APIs, modules, a typed IR, native code generation, and an explicit `unsafe` boundary.
