# Seaphire OS-level direction

Seaphire Era 2 Delta now has a freestanding target contract for x86_64.

## Layers

`INU source -> lexer/parser -> safety/type pass -> IR -> machine backend -> ELF -> bootloader -> kernel`

The repository currently implements the lexer/parser, a conservative safety pass, and an
x86_64 kernel ABI/entry scaffold. General machine-code lowering and a real bootable image
are intentionally separate milestones; the project does not claim that the reference
interpreter is already a native compiler.

## Hardware targets

Initial target: `x86_64` in freestanding mode.

Planned targets:

- x86_64
- AArch64
- RISC-V 64

## Kernel responsibilities

- physical page allocator
- virtual memory and page tables
- interrupt/exception handling
- scheduler
- drivers
- syscall ABI
- safe user/kernel boundary

All hardware-facing code should be isolated under `kernel/` and exposed to safe Seaphire
through narrow interfaces.
