# Seaphire Era 2 Delta — Native Backend Milestone 5

Milestone 5 moves the native backend from an untyped instruction stream toward a typed intermediate representation and adds read-only string data lowering.

## Implemented

- IR value types: `i64`, `bool`, `str`
- IR verifier for operand ranges and type-safe arithmetic/branches/returns/printing
- String literals in `.inu` source
- String literals lowered into ELF `.rodata`
- `println "text"` lowered through `puts`
- Numeric `println` continues to use `printf`
- Per-function string labels to prevent symbol collisions
- Existing branches, loops, calls, and arithmetic retained
- Native executable remains x86_64 ELF

## Example

```inu
fn main() -> i64 {
    println "Hello from Seaphire";
    println 42;
    return 0;
}
```

## Pipeline

`.inu -> lexer/parser -> typed linear IR -> IR verification -> x86_64 lowering -> .rodata/.text -> assembler -> ELF`

## Deliberate limits

The current string slice is literal-only: strings can be printed but are not yet general-purpose `str` locals or function parameters. The next stage should introduce a real string/reference type model, data pointers, and ownership-aware references.

## Next

Milestone 6 should target references and slices, a stronger SSA/control-flow representation, and the first register-allocation pass. Freestanding ELF should follow once runtime dependencies are removed.
