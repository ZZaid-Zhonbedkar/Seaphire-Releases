# Milestone 10 — Real Owned `slice_i64`

Milestone 10 adds the first real pointer+length owned slice to the native backend.

## Supported

- `slice_i64` local type
- `slice_i64(length)` heap allocation
- contiguous i64 storage with a pointer+length header
- checked `slice_at(slice, index)` reads
- checked `slice_set(slice, index, value)` writes
- `slice_len(slice)` length query
- `move_slice(slice)` ownership transfer
- static use-after-move rejection
- `free_slice(slice)` deallocation
- slices cannot participate in numeric arithmetic
- existing string-literal `slice_len` / `slice_at` behavior remains supported

Example:

```inu
fn main() -> i64 {
    let s: slice_i64 = slice_i64(3);
    let a: i64 = slice_set(s, 0, 11);
    let b: i64 = slice_set(s, 1, 22);
    let c: i64 = slice_set(s, 2, 33);
    println slice_len(s);
    println slice_at(s, 1);
    let t: slice_i64 = move_slice(s);
    println slice_at(t, 2);
    return free_slice(t);
}
```

The native representation is one owned heap allocation containing a two-word
header followed by the i64 element storage. The public language model treats it
as an opaque pointer+length value, so callers cannot forge its pointer or length.
Indexing is bounds checked and aborts on out-of-range access.

This remains a deliberately small ownership slice. General generic slices,
borrowed slice parameters, automatic drop, and arbitrary aggregates are future
work.
