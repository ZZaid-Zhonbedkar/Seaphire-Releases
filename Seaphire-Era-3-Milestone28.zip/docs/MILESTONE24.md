# Milestone 24 — Dependency Solver + Namespaces/Imports

Era 3 package management now has deterministic dependency resolution and source-level package namespaces.

## Dependency solving

`seaphire package resolve` resolves the project's `[dependencies]` against the local `.inupkg` registry.

Supported constraints include:

- exact versions: `1.2.0`
- caret ranges: `^1.2.0`
- tilde ranges: `~1.2.0`
- comparator sets: `>=1.0.0 <2.0.0`
- wildcard minor versions: `1.2.*`
- `*` / `latest`

Resolution is deterministic: the highest compatible local version is selected, transitive dependencies are traversed in sorted order, and `seaphire.lock` is written in stable key order.

Cycles and unsatisfied constraints are reported as dependency errors.

## Namespaces and imports

Syntax v2 adds a deliberately structured, non-Rust import form:

```text
IMPORT hello-lib::hello_value
```

or:

```text
IMPORT hello-lib::*
```

Imports resolve only against packages recorded in `seaphire.lock`. The native frontend expands imported `.inu` functions before normal Syntax v2 lowering.

Unknown packages, missing symbols, ambiguous symbols, and malformed imports are diagnosed explicitly.

## Commands

```text
seaphire package resolve [registry-dir]
seaphire package install <name> [registry-dir]
```

`install` now resolves the complete project graph plus the requested package and records dependency metadata in the lockfile.

## Deliberate scope

The registry remains local/offline. Network publishing, package signing, and a public registry protocol remain planned for M25.
