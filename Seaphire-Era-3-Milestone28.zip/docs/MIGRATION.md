# Era 2 Delta migration

| Old idea | Era 2 Delta |
|---|---|
| legacy source extension | `.inu` source |
| the old package-manager interface | `seaphire` project command |
| the old package manifest | `seaphireinit.toml` |
| `_VARS` / `_MAIN` sections | `fn main() { ... }` |
| `MOV` / command-shaped arithmetic | ordinary expressions and assignment |
| implicit mutation | `let mut` |
| stringly-typed memory instructions | typed language constructs |

The preserved historical folders may still contain experimental Era-2 code, but new Delta projects should use `.inu` and `seaphireinit.toml`.
