# Seaphire Tooling

The formal user-facing command is `sea`.

```text
sea init
sea build
sea run <file.inu>
sea check <file.inu>
sea fmt <file.inu>
sea lint <file.inu> [--json]
sea symbols <file.inu>
sea install <package> [registry-dir]
sea uninstall <package>
sea search [query] [registry-dir]
sea info <package> [registry-dir]
```

`seaphire` remains available as the lower-level compatibility command. `sea`
is the preferred package-manager/developer-tool entry point from Era 3 onward.
