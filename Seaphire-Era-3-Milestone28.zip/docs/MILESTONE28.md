# Milestone 28 — CPhire

Milestone 28 establishes the first direct native C integration layer for Seaphire Era 3.

## C ABI declarations

Syntax v2 now accepts:

```text
EXTERN FUNC c_add(A: int, B: int) -> int;
```

The declaration is lowered to an external symbol and is resolved by the native linker.

## `sea c build`

```text
sea c build src/main.inu native/add.c -o build/app
```

C inputs are compiled with the host C compiler, then linked into the native Seaphire executable.
Object files may also be passed directly.

## CPhire package

`cphire 0.1.0` provides:

- `include/cphire.h`
- `cphire/cphire.c`
- Seaphire-side `EXTERN FUNC` contracts
- `native-c-abi-v1` metadata
- x86-64 System V scalar `int64_t` ABI coverage

CPhire is deliberately a direct compiled ABI layer, unlike Pyphire's process/protocol bridge.

## Scope boundary

Future CPhire milestones can add pointers, C strings, structs, callbacks, `errno`, shared-library loading, platform ABI profiles and generated bindings.
