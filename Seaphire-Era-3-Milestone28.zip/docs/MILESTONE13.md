# Milestone 13 — Heap Structs and Automatic Drop

Milestone 13 extends user-defined structs with heap ownership.

## Syntax

```inu
struct Point { x: i64; y: i64; }

fn main() -> i64 {
    let p: Point = box Point { x: 10, y: 32 };
    let q: Point = move p;
    return q.x + q.y;
}
```

## Added

- `box StructName { field: value, ... }` heap construction
- owned heap struct representation backed by the existing owned `slice_i64` allocator
- field reads and writes on heap structs
- `move StructName` ownership transfer
- static use-after-move rejection through the existing move checker
- automatic `free_slice` drop on normal function exit and returns
- return-value preservation before automatic drop
- stack-struct behavior from Milestone 12 remains supported

## Safety model

Heap structs own exactly one allocation. Moving a heap struct transfers that allocation; the source is no longer valid and is never freed. Automatic cleanup frees only the currently-live owner. Borrowed references remain non-owning.

## Current limits

- fields are still `i64`
- heap structs currently use the internal slice allocator representation
- nested structs, generic structs, struct-return ABI, and precise destructor/lifetime analysis remain future work
- native output remains host-linked rather than freestanding
