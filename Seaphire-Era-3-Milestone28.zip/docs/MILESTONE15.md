# Milestone 15 — OG Seaphire Syntax Restoration

Seaphire Era 2 Delta now has an assembly-inspired compatibility frontend for the original Seaphire style.

## Design goal

Seaphire's implementation may use a modern typed IR and ownership machinery internally, but source code does not need to look like Rust. The OG surface is intentionally quirky and opcode/operand oriented.

## Supported OG surface

```text
_VARS: 3
int X 10
int Y 7
int Z 0
_MAIN:
MOV Z, X
ADD Z, Y
PRINT Z
_END:
```

Supported compatibility operations in this milestone:

- `MOV dst, value`
- `ADD dst, value`
- `SUB dst, value`
- `MUL dst, value`
- `DIV dst, value`
- `PRINT value`
- `PRINT_COOL value`
- `IF [condition]`
- `ELIF [condition]`
- `ELSE`
- `LOOP`
- `JUMPIF`
- `RET value`
- `RETURN value`
- `DEL name` (recognized compatibility no-op for now)

Variable declarations use the original `_VARS:` / `int name value` style. The current native bridge maps `int` to Seaphire's internal `i64` representation.

## Architecture

```text
OG .inu source
     |
     v
og_seaphire.py
     |
     v
Seaphire native-compatible syntax
     |
     v
Typed IR / verifier / ownership machinery
     |
     v
x86-64 assembly -> object -> ELF
```

The bridge is deliberately a frontend compatibility layer. It does not replace the native backend.

## Why this exists

Earlier Era 2 work had drifted toward Rust-like surface syntax. Milestone 15 restores the original Seaphire identity while preserving the native compiler work already completed.

The long-term direction is to grow the OG syntax into a first-class Seaphire grammar rather than requiring users to understand Rust.
