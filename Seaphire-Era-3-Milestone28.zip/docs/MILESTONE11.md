# Milestone 11 — Borrowed Slice References

Milestone 11 extends the native backend with non-owning references to an existing `slice_i64` header.

## Supported

- `&slice_i64` shared borrowed slice references
- `&mut slice_i64` exclusive borrowed slice references
- borrowed slice references as function parameters
- `&mut slice_i64` is accepted where `&slice_i64` is expected
- `slice_ref_len(ref)` reads the borrowed slice length
- `slice_ref_at(ref, index)` performs bounds-checked reads
- `slice_ref_set(ref, index, value)` performs bounds-checked writes through `&mut slice_i64`
- shared/mutable borrow conflict rejection
- immutable-local to mutable-borrow rejection
- borrowed slices do not own or free the underlying allocation

Example:

```inu
fn read(s: &slice_i64) -> i64 {
    return slice_ref_at(s, 1);
}

fn main() -> i64 {
    let s: slice_i64 = slice_i64(2);
    let _a: i64 = slice_set(s, 0, 11);
    let _b: i64 = slice_set(s, 1, 22);
    let r: &slice_i64 = &s;
    println slice_ref_len(r);
    return read(r);
}
```

Mutable access:

```inu
fn set(s: &mut slice_i64) -> i64 {
    return slice_ref_set(s, 0, 42);
}
```

## Safety model

Borrowed slice references are pointers to an existing owned `slice_i64` header. They do not transfer ownership and must not be passed to `free_slice`.

The checker conservatively rejects overlapping shared/mutable borrows and rejects `&mut slice_i64` from immutable locals. Reference parameters cannot escape by being returned.

This remains a deliberately small Rust-like ownership slice. General slice syntax such as `&[i64]`, arbitrary sub-slice construction, lifetime parameters, and full drop semantics remain future work.
