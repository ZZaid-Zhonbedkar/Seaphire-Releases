# Milestone 9 — Owned Heap Boxes and Moves

Milestone 9 adds the first owned heap value to the native backend: `box_i64`.

## Supported

- `box_i64` local type
- `box_i64(value)` heap allocation
- `box_get(box)` checked typed load
- `move_box(box)` ownership transfer
- static use-after-move rejection
- `free_box(box)` explicit deallocation
- boxes cannot participate in numeric arithmetic
- native backend uses host `malloc`/`free`

Example:

```inu
fn main() -> i64 {
    let p: box_i64 = box_i64(41);
    let q: box_i64 = move_box(p);
    println box_get(q);
    return free_box(q);
}
```

This is intentionally a small ownership slice, not full Rust ownership. Allocation is host-linked, drops are explicit, and boxes cannot yet be returned from functions or stored in aggregates. Real pointer+length slices remain the next memory milestone.
