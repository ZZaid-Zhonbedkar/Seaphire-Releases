# Milestone 21 — Standard Library and `.inupkg` Packaging

Milestone 21 establishes Seaphire's native project/package boundary.

## Manifest

`seaphireinit.toml` supports a first-class `[package]` section with `name`,
`version`, and `edition = "era2-delta"`, plus a `[dependencies]` table.
The source extension remains `.inu`.

## Packages

`seaphire package check` validates the package metadata.

`seaphire package build [output-dir]` emits `name-version.inupkg`. The archive
contains the manifest, project `.inu` sources, and bundled `stdlib/` sources.
The `.inupkg` container is ZIP-based for Era 2 Delta; registry solving is
intentionally deferred to the post-Era-2 ecosystem.

## Standard library seed

`stdlib/core/prelude.inu` and `stdlib/io/print.inu` establish the standard
library tree. Native `PRINT`/`println` remain compiler intrinsics for now.
