# Seaphire roadmap — Era 2 Delta

## Completed native milestones

- [x] `.inu` source model and `seaphireinit.toml`
- [x] conservative safety/type pass
- [x] x86_64 freestanding ABI scaffold
- [x] native x86_64 code generation — Milestone 3
- [x] typed linear IR + comparisons + branches + loops + function calls — Milestone 4
- [x] typed references + checked slice access + CFG verification — Milestone 6

## Next

- [x] typed IR verifier / explicit CFG validation
- [ ] SSA form / phi nodes
- [x] ownership/borrow IR
- [ ] strings and data sections
- [x] conservative local references and bounded string-slice access
- [ ] general bounds-checked `&[T]` slices
- [x] conservative `&mut` borrowing and conflict checks
- [ ] register allocation and optimization
- [ ] freestanding ELF writer
- [ ] bootable image generation
- [ ] page allocator and virtual memory
- [ ] interrupts, scheduler and syscalls

## Milestone 8 completed
- Typed `&i64` / `&mut i64` function parameters
- Mutable dereference stores
- Reference argument checking and forwarding
- Lexical borrow regions
- Exclusive/shared borrow conflict checking

## Milestone 9
- Owned `box_i64` heap values
- Explicit move checking
- Use-after-move rejection
- Typed heap load/free operations
- Host `malloc`/`free` integration


## Milestone 10 completed
- Owned `slice_i64` pointer+length values
- Heap-backed contiguous i64 storage
- Bounds-checked slice reads and writes
- Slice ownership moves and use-after-move rejection
- Explicit slice deallocation

## Milestone 11 completed
- Borrowed `&slice_i64` / `&mut slice_i64` references
- Slice references as function parameters
- Bounds-checked borrowed reads and mutable writes
- Mutable-to-shared reference compatibility
- Conservative aliasing conflict checks

## Future slice work
- Rust-style `&[i64]` syntax
- Non-owning sub-slice construction
- Lifetime parameters and more precise region inference

## Milestone 12
- User-defined structs with i64 fields
- Field access and mutation
- References to struct fields
- Initial ownership-aware struct moves

## Milestone 13 completed
- Heap-allocated user-defined structs
- Owned heap-struct moves
- Static use-after-move rejection for heap structs
- Automatic heap-struct cleanup on function exit/return
- Heap field reads and writes
- Reuse of the proven owned slice allocator representation

## Future aggregate work
- Nested structs and aggregate fields
- Structs containing slices/boxes/references
- First-class aggregate IR and native struct layout ABI
- User-defined destructors/drop traits

## Milestone 14 completed
- Nested aggregate structs with recursive layout calculation
- 8-byte x86-64 aggregate alignment and deterministic field slots
- Nested literals and nested field access/mutation
- Heap aggregates containing owning `slice_i64` and `box_i64` fields
- Ownership-moving aggregate field reads and safe slot clearing
- Aggregate member cleanup and layout metadata

## Milestone 15 completed
- OG assembly-inspired compatibility frontend
- Seaphire syntax identity documented without making Rust syntax canonical

## Milestone 16 completed
- Structured Seaphire v2 functions: `FUNC name(args) -> type { ... }`
- Typed shorthand functions such as `int name(args) { ... }`
- C-like braces with assembly-inspired operations inside blocks
- First native array syntax: `int values[] = [...]` and `int values[N]`
- Checked array reads/writes lowered to `slice_at` / `slice_set`
- Syntax v2 compatibility frontend and tests

## Next: Milestone 17
- Enums and tagged unions
- Discriminant layout and exhaustive matching groundwork

## Milestone 17 completed
- Seaphire `ENUM` declarations
- Variant discriminants
- `MATCH` / `CASE` / `DEFAULT` control-flow lowering
- Payload-bearing variants with a temporary tagged-value ABI
- Constructor arity checking
- Native enum/tagged-value tests

## Next: Milestone 19 — Generic functions

- explicit generic function syntax (`FUNC name<T>(...)`)
- compile-time monomorphization into concrete symbols
- scalar `int`/`i64` instantiations
- compile-time rejection of unsupported type arguments

Milestone 18
- First-class tagged-union IR
- Explicit discriminant/payload layout
- Payload extraction/pattern binding
- Exhaustiveness diagnostics

## Milestone 17 completed
- Seaphire `ENUM` declarations
- Deterministic variant discriminants
- `MATCH` / `CASE` / `DEFAULT` syntax
- Payload-bearing variants
- Temporary tagged-value ABI
- Payload pattern binding groundwork
- Enum/tagged-value native tests

## Next: Milestone 18
- First-class tagged-union IR
- Explicit discriminant/payload layout and alignment
- Payload extraction without packed-value ABI
- Exhaustiveness diagnostics
- Better enum type checking

## Milestone 18
- First-class tagged-union IR boundary
- Explicit tag/payload operations
- Exhaustive `MATCH` checking
- Preserve temporary host ABI only at final lowering boundary


## Era 2 Delta finish line

- Milestone 20: Generic structs / aggregate specialization — complete.
- Milestone 21: Standard library + package/build model hardening.
- Milestone 22: Era 2 Delta finalization, conformance suite, and release tooling.

After Milestone 22, Era 2 Delta is considered complete.

## Era 2 Delta finish

- Milestone 21: standard library + `.inupkg` packaging foundation — complete
- Milestone 22: final conformance, release tooling, and language freeze — complete

**ERA 2 DELTA: COMPLETE.**

## Era 3 — Package Ecosystem

### Milestone 23 completed
- `.inupkg` metadata envelope (`inupkg.json`)
- Local registry index
- Offline package installation
- `seaphire.lock`
- Installed package listing
- Era 3 package edition

### Next: Milestone 24
- Dependency version solving
- Package namespaces/imports
- Registry publishing workflow

## Era 3 — Milestone 24

- Deterministic local dependency solver with semver constraints
- Transitive dependency resolution and cycle diagnostics
- Stable `seaphire.lock` dependency metadata
- Package namespaces and `IMPORT package::symbol` / `IMPORT package::*`
- Native frontend import expansion before Syntax v2 lowering

## Era 3 — Milestone 25

- Ed25519 package signatures and publisher key IDs
- SHA-256 package integrity metadata
- Local registry publishing workflow
- Detached `.inupkg.sig` signatures
- Signature verification and tamper detection

### Next: Milestone 26
- Standard library expansion
- richer core/io/path/process APIs
- package-aware stdlib organization
- native runtime utilities

## Era 3 — Milestone 26

- Expanded standard library into `core`, `io`, `path`, and `process` modules.
- Added local package-aware `std::module::symbol` imports.
- Added native string-typed function parameters.
- Added process ID, runtime clock, and process-exit runtime primitives.
- Upgraded `.inupkg` metadata to format 3 with stdlib metadata.

### Next: Milestone 27
- Toolchain and IDE developer experience
- formatter/linter foundation
- diagnostics and source spans
- language-server-ready symbol/index data


## Era 3 — Milestone 27

Developer tooling and the formal `sea` package manager are established. Pyphire
provides the first Python interoperability boundary.

- M27: `sea`, formatter, linter, symbols, diagnostics, Pyphire 0.1.0
- M28+: native runtime/OS expansion and broader systems libraries

- [x] direct C ABI integration + CPhire package — Milestone 28
- [ ] C pointers/strings/structs/callbacks and generated bindings — future Era 3
