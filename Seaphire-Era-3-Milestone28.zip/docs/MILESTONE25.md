# Milestone 25 — Registry Publishing + Package Signing

Era 3 Milestone 25 adds a local/offline publishing and authenticity layer for `.inupkg` packages.

## Delivered

- Ed25519 publisher key generation through the host OpenSSL toolchain.
- Deterministic package SHA-256 digest calculation.
- Detached package signatures (`.inupkg.sig`) with machine-readable signature metadata.
- Stable 16-hex-character publisher key IDs derived from the public key.
- Registry publication workflow that copies packages, signatures, and publisher public keys into a registry.
- Registry index signature metadata containing algorithm, key ID, signature file, and package SHA-256.
- Signature verification and package tamper detection.
- CLI commands:
  - `seaphire package keygen <private-key>`
  - `seaphire package sign <package.inupkg> <private-key> [signature]`
  - `seaphire package verify <package.inupkg> <signature> <public-key>`
  - `seaphire package publish <package.inupkg> <registry-dir> <private-key>`

The registry remains filesystem-based and offline. Network transport, authenticated accounts, and remote registry APIs remain future work.

## Security boundary

Private keys are never stored in `.inupkg` archives or registry indexes. Publishing copies only the package, detached signature, and corresponding public key. Consumers can verify the package bytes against the detached signature before trusting the archive.
