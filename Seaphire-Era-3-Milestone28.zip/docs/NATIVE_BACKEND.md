# Native backend — Era 2 Delta Milestone 4

Milestone 4 upgrades the native compiler from a straight-line expression compiler into a small control-flow compiler with a typed linear intermediate representation (IR).

```text
.inu
  -> native lexer/parser
  -> safety + call validation
  -> typed linear i64 IR
  -> control-flow lowering
  -> x86_64 AT&T assembly
  -> system assembler
  -> native ELF executable
```

## Implemented

- Native `seaphirec-native` compiler executable.
- `.inu` source files remain the only source model.
- `i64` and boolean values (booleans lower to `0`/`1`).
- Arithmetic: `+`, `-`, `*`, `/`.
- Comparisons: `==`, `!=`, `<`, `<=`, `>`, `>=`.
- `if` / `else` control flow.
- `while` loops.
- Multiple functions with `i64` parameters and `i64` results.
- Native calls using the x86_64 System V integer argument registers (up to six arguments in this milestone).
- Compile-time immutable-assignment rejection.
- Typed linear IR instructions for constants, moves, arithmetic, comparisons, labels, jumps, branches, calls, printing and returns.
- Real x86_64 machine-code generation through the platform assembler and linker.
- Native ELF output verified in the build environment.

## Example

```inu
fn add(a: i64, b: i64) -> i64 {
    return a + b;
}

fn main() -> i64 {
    let mut total: i64 = 0;
    let mut i: i64 = 0;

    while i < 5 {
        total = total + i;
        i = i + 1;
    }

    if total == 10 {
        println add(total, 32);
    }

    return total;
}
```

## Deliberate boundaries

Milestone 4 is still not a complete standalone compiler. `println` uses libc, so native output is not freestanding yet. The IR is typed around the current `i64` core but is intentionally linear rather than a full SSA optimizer.

## Next backend stages

1. First-class typed IR module and verifier.
2. String/data-section lowering.
3. Reference/borrow IR and bounds-checked slices.
4. Better call lowering and stack/register ABI handling.
5. Register allocation and optimization.
6. Freestanding ELF writer with no libc.
7. Kernel entry/runtime integration.
8. AArch64 backend.

## Milestone 6

The native backend now includes a conservative local reference subset (`&i64` / dereference), reference-flow verification, explicit CFG target verification, and checked string-literal slice access via `slice_len` and `slice_at`. General borrowed slices and `&mut` remain future work.
