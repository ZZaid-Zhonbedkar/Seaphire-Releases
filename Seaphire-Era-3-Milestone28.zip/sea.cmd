@echo off
python "%~dp0tools\sea" %*
