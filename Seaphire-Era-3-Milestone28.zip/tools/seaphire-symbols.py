#!/usr/bin/env python3
import json,re,sys
from pathlib import Path
p=Path(sys.argv[1])
text=p.read_text(encoding='utf-8')
items=[]
for i,line in enumerate(text.splitlines(),1):
    for kind,pat in [('function',r'^\s*FUNC\s+([A-Za-z_]\w*)'),('struct',r'^\s*STRUCT\s+([A-Za-z_]\w*)'),('enum',r'^\s*ENUM\s+([A-Za-z_]\w*)')]:
        m=re.match(pat,line)
        if m: items.append({'kind':kind,'name':m.group(1),'line':i})
print(json.dumps({'file':str(p),'symbols':items},indent=2))
