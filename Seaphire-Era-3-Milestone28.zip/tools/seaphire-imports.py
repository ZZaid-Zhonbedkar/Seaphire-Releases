#!/usr/bin/env python3
"""Resolve Seaphire Era 3 package imports from .seaphire/packages."""
import json, re, sys
from pathlib import Path

def load_lock(root):
    p=Path(root)/'seaphire.lock'
    return json.loads(p.read_text()) if p.exists() else {'packages':{}}


def extract_func(text, sym):
    m=re.search(r'(?m)^\s*FUNC\s+'+re.escape(sym)+r'\b[^\n]*\{', text)
    if not m: return None
    start=m.start(); pos=m.end()-1; depth=0; quote=False; esc=False
    for i in range(pos,len(text)):
        ch=text[i]
        if quote:
            if esc: esc=False
            elif ch=='\\': esc=True
            elif ch=='"': quote=False
            continue
        if ch=='"': quote=True; continue
        if ch=='{': depth+=1
        elif ch=='}':
            depth-=1
            if depth==0: return text[start:i+1]
    raise ValueError(f'unterminated imported function: {sym}')


def extract_decl(text, sym):
    m=re.search(r'(?m)^\s*EXTERN\s+FUNC\s+'+re.escape(sym)+r'\b[^;]*;\s*$', text)
    return m.group(0).strip() if m else None

def resolve(root, src):
    root=Path(root); lock=load_lock(root); lines=src.splitlines(); out=[]; imported=set()
    for line in lines:
        mstd=re.match(r'^\s*IMPORT\s+std::([A-Za-z_][A-Za-z0-9_]*)::([A-Za-z_][A-Za-z0-9_]*|\*)\s*$',line)
        mpkg=re.match(r'^\s*IMPORT\s+([A-Za-z0-9_.-]+)::([A-Za-z_][A-Za-z0-9_]*|\*)\s*$',line)
        if mstd:
            module,sym=mstd.groups()
            files=sorted((root/'stdlib'/module).rglob('*.inu'))
            if not files: raise ValueError(f'stdlib module not found: std::{module}')
            found=[]
            for f in files:
                text=f.read_text(encoding='utf-8')
                funcs=re.findall(r'(?m)^\s*(?:EXTERN\s+)?FUNC\s+([A-Za-z_]\w*)',text)
                if sym=='*' or sym in funcs: found.append((f,text))
            if sym!='*' and not found: raise ValueError(f'stdlib symbol not found: std::{module}::{sym}')
            if sym!='*' and len(found)>1: raise ValueError(f'stdlib symbol is ambiguous: std::{module}::{sym}')
            for f,text in found:
                key=str(f.resolve())+':'+sym
                if key in imported: continue
                imported.add(key)
                if sym=='*':
                    out.append(f'// IMPORT std::{module}::*')
                    out.extend(text.splitlines())
                else:
                    mm=extract_func(text,sym) or extract_decl(text,sym)
                    if not mm: raise ValueError(f'could not extract stdlib function: std::{module}::{sym}')
                    out.append(f'// IMPORT std::{module}::{sym}')
                    out.extend(mm.splitlines())
            continue
        if not mpkg:
            if re.match(r'^\s*IMPORT\b',line): raise ValueError('invalid IMPORT syntax; use IMPORT package::symbol or IMPORT std::module::symbol')
            out.append(line); continue
        pkg,sym=mpkg.groups()
        if pkg not in lock.get('packages',{}): raise ValueError(f'package not installed: {pkg}')
        base=root/'.seaphire'/'packages'/pkg/lock['packages'][pkg]['version']
        files=sorted(base.rglob('*.inu'))
        if not files: raise ValueError(f'package has no .inu sources: {pkg}')
        found=[]
        for f in files:
            text=f.read_text(encoding='utf-8')
            funcs=re.findall(r'(?m)^\s*(?:EXTERN\s+)?FUNC\s+([A-Za-z_]\w*)',text)
            if sym=='*' or sym in funcs: found.append((f,text))
        if sym!='*' and len(found)==0: raise ValueError(f'import symbol not found: {pkg}::{sym}')
        if sym!='*' and len(found)>1: raise ValueError(f'import symbol is ambiguous: {pkg}::{sym}')
        for f,text in found:
            key=str(f.resolve())+':'+sym
            if key in imported: continue
            imported.add(key)
            if sym=='*':
                out.append(f'// IMPORT {pkg}::*')
                out.extend(text.splitlines())
            else:
                mm=extract_func(text,sym) or extract_decl(text,sym)
                if not mm: raise ValueError(f'could not extract imported function: {pkg}::{sym}')
                out.append(f'// IMPORT {pkg}::{sym}')
                out.extend(mm.splitlines())
    return '\n'.join(out)+'\n'

if __name__=='__main__':
    if len(sys.argv)!=4: raise SystemExit('usage: seaphire-imports.py root input output')
    try:
        root,inp,out=sys.argv[1:]
        Path(out).write_text(resolve(root,Path(inp).read_text(encoding='utf-8')),encoding='utf-8')
    except Exception as e:
        print('seaphire import resolver:',e,file=sys.stderr); sys.exit(1)
