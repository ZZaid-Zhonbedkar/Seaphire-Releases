#!/usr/bin/env python3
import json,re,sys
from pathlib import Path

def lint(path):
    p=Path(path); text=p.read_text(encoding='utf-8'); issues=[]
    if p.suffix != '.inu': issues.append((p,1,'E000','source file must use .inu'))
    funcs={}
    for i,line in enumerate(text.splitlines(),1):
        if line.rstrip()!=line: issues.append((p,i,'W001','trailing whitespace'))
        if len(line)>120: issues.append((p,i,'W002','line exceeds 120 columns'))
        m=re.match(r'\s*FUNC\s+([A-Za-z_]\w*)\s*\(',line)
        if m:
            n=m.group(1)
            if n in funcs: issues.append((p,i,'E101',f'duplicate function: {n}'))
            funcs[n]=i
        if re.match(r'\s*IMPORT\s+',line) and not re.match(r'\s*IMPORT\s+(std::[A-Za-z_]\w*::[A-Za-z_]\w*|std::[A-Za-z_]\w*::\*|[A-Za-z0-9_.-]+::[A-Za-z_]\w*|[A-Za-z0-9_.-]+::\*)\s*$',line):
            issues.append((p,i,'E201','invalid IMPORT syntax'))
    return issues

def main():
    if len(sys.argv)<2: raise SystemExit('usage: sea lint <file...> [--json]')
    args=sys.argv[1:]; as_json='--json' in args; args=[a for a in args if a!='--json']; issues=[]
    for a in args: issues.extend(lint(a))
    if as_json:
        print(json.dumps([{'file':str(p),'line':ln,'code':c,'message':m} for p,ln,c,m in issues],indent=2))
    else:
        for p,ln,c,m in issues: print(f'{p}:{ln}: {c}: {m}')
        print('lint passed' if not issues else f'{len(issues)} issue(s)')
    return 1 if issues else 0
if __name__=='__main__': raise SystemExit(main())
