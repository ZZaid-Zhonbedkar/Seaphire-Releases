#!/usr/bin/env python3
import sys,re
from pathlib import Path

def fmt(text):
    out=[]; indent=0
    for raw in text.splitlines():
        s=raw.strip()
        if not s:
            if out and out[-1] != '': out.append('')
            continue
        if s.startswith('}') or s.startswith('CASE ') or s.startswith('DEFAULT'):
            indent=max(0,indent-1)
        # Normalize common syntax-v2 spacing without touching string contents.
        s=re.sub(r'[ \t]+$', '', s)
        s=re.sub(r'\b(FUNC|STRUCT|ENUM|IMPORT|RET)\s+', lambda m:m.group(1)+' ', s)
        s=re.sub(r'\s*->\s*', ' -> ', s)
        s=re.sub(r',\s*', ', ', s)
        s=re.sub(r'\s+\{', ' {', s)
        out.append('    '*indent+s)
        if s.endswith('{'):
            indent += 1
    while out and out[-1]=='': out.pop()
    return '\n'.join(out)+'\n'

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('usage: sea fmt <file.inu>')
    p=Path(sys.argv[1]); p.write_text(fmt(p.read_text(encoding='utf-8')),encoding='utf-8')
    print('formatted '+str(p))
