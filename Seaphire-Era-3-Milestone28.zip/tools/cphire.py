#!/usr/bin/env python3
import os, shutil, subprocess, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
NATIVE = ROOT / 'build' / 'native' / 'seaphirec-native'

def die(msg): raise SystemExit('cphire: ' + msg)

def build(args):
    if '-o' not in args: die('usage: sea c build <main.inu> <file.c|file.o>... -o <output>')
    oi=args.index('-o')
    if oi<2 or oi+1>=len(args): die('usage: sea c build <main.inu> <file.c|file.o>... -o <output>')
    inu=Path(args[0]); sources=[Path(x) for x in args[1:oi]]; out=Path(args[oi+1])
    if not inu.exists(): die(f'input not found: {inu}')
    if not NATIVE.exists():
        subprocess.run([str(ROOT/'tools'/'seaphire'),'build','--native'],check=True)
    with tempfile.TemporaryDirectory(prefix='cphire-') as td:
        td=Path(td); objects=[]
        include_dirs=[ROOT/'packages'/'cphire-0.1.0'/'include']
        lock=ROOT/'seaphire.lock'
        if lock.exists():
            import json
            data=json.loads(lock.read_text())
            for name,meta in data.get('packages',{}).items():
                base=ROOT/'.seaphire'/'packages'/name/meta['version']
                inc=base/'include'
                if inc.is_dir(): include_dirs.append(inc)
        for src in sources:
            if not src.exists(): die(f'input not found: {src}')
            if src.suffix == '.o': objects.append(src); continue
            if src.suffix not in ('.c','.cc','.cpp'): die(f'unsupported C input: {src}')
            obj=td/(src.stem+'.o')
            cc=os.environ.get('CC','cc')
            cmd=[cc,'-std=c11','-O2','-fPIC'] + sum((['-I',str(d)] for d in include_dirs),[]) + ['-c',str(src),'-o',str(obj)]
            subprocess.run(cmd,check=True)
            objects.append(obj)
        out.parent.mkdir(parents=True,exist_ok=True)
        subprocess.run([str(NATIVE),str(inu),str(out),*map(str,objects)],check=True)

def main():
    if len(sys.argv)<2: die('usage: cphire <build> ...')
    if sys.argv[1]=='build': build(sys.argv[2:]); return
    if sys.argv[1] in ('--version','version'): print('cphire 0.1.0'); return
    die('unknown command')
if __name__=='__main__': main()
