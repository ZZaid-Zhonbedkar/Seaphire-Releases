#!/usr/bin/env python3
import base64, hashlib, json, os, re, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MANIFEST = ROOT / 'seaphireinit.toml'

NAME_RE = r'[A-Za-z0-9_.-]+'

def manifest(path=MANIFEST):
    text=Path(path).read_text(encoding='utf-8')
    m=re.search(r'(?m)^name\s*=\s*"('+NAME_RE+r')"$', text)
    v=re.search(r'(?m)^version\s*=\s*"([^"]+)"$', text)
    e=re.search(r'(?m)^edition\s*=\s*"([^"]+)"$', text)
    if not (m and v and e): raise SystemExit('package manifest invalid: missing name/version/edition')
    deps={}; in_deps=False
    for line in text.splitlines():
        if line.strip() == '[dependencies]': in_deps=True; continue
        if in_deps and line.startswith('['): break
        if in_deps:
            x=re.match(r'\s*('+NAME_RE+r')\s*=\s*"([^"]+)"', line)
            if x: deps[x.group(1)] = x.group(2)
    return {'name':m.group(1),'version':v.group(1),'edition':e.group(1),'dependencies':deps}

def version(v):
    m=re.match(r'^(\d+)(?:\.(\d+))?(?:\.(\d+))?(?:-([0-9A-Za-z.-]+))?$', v)
    if not m: raise ValueError('invalid semantic version: '+v)
    return (int(m.group(1)),int(m.group(2) or 0),int(m.group(3) or 0),m.group(4) or '')

def cmpver(a,b): return (version(a)>version(b))-(version(a)<version(b))

def satisfies(v, constraint):
    c=constraint.strip()
    if c in ('','*','latest'): return True
    # Space-separated comparator sets: all must match.
    for part in c.split():
        if part.startswith('^'):
            base=part[1:]; bv=version(base)
            if cmpver(v,base)<0: return False
            upper=(bv[0]+1,0,0,'') if bv[0]>0 else ((0,bv[1]+1,0,'') if bv[1]>0 else (0,0,bv[2]+1,''))
            if version(v)>=upper: return False
        elif part.startswith('~'):
            base=part[1:]; bv=version(base)
            if cmpver(v,base)<0 or version(v)>=(bv[0],bv[1]+1,0,''): return False
        elif part.startswith('>='):
            if cmpver(v,part[2:])<0: return False
        elif part.startswith('<='):
            if cmpver(v,part[2:])>0: return False
        elif part.startswith('>'):
            if cmpver(v,part[1:])<=0: return False
        elif part.startswith('<'):
            if cmpver(v,part[1:])>=0: return False
        elif part.endswith('.*'):
            if not v.startswith(part[:-1]): return False
        elif cmpver(v,part)!=0:
            return False
    return True



def sha256_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def run_openssl(args, stdin=None):
    p=subprocess.run(['openssl']+args,input=stdin,capture_output=True)
    if p.returncode:
        raise SystemExit((p.stderr or p.stdout).decode(errors='replace').strip() or 'openssl failed')
    return p.stdout

def keygen(out):
    out=Path(out); out.parent.mkdir(parents=True,exist_ok=True)
    run_openssl(['genpkey','-algorithm','ED25519','-out',str(out)])
    pub=Path(str(out)+'.pub.pem')
    data=run_openssl(['pkey','-in',str(out),'-pubout'])
    pub.write_bytes(data)
    keyid=hashlib.sha256(data).hexdigest()[:16]
    print(json.dumps({'key':str(out),'public_key':str(pub),'key_id':keyid},sort_keys=True))

def sign(pkg,key,out=None):
    pkg=Path(pkg); key=Path(key); out=Path(out) if out else Path(str(pkg)+'.sig')
    digest=hashlib.sha256(pkg.read_bytes()).digest()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(digest); tmp=f.name
    try: sig=run_openssl(['pkeyutl','-sign','-inkey',str(key),'-in',tmp])
    finally: os.unlink(tmp)
    out.write_bytes(sig)
    pub=run_openssl(['pkey','-in',str(key),'-pubout'])
    keyid=hashlib.sha256(pub).hexdigest()[:16]
    side=Path(str(out)+'.json')
    side.write_text(json.dumps({'format':1,'algorithm':'ed25519','key_id':keyid,'sha256':sha256_file(pkg),'signature':'base64:'+base64.b64encode(sig).decode()},indent=2,sort_keys=True)+'\n')
    print(out)

def verify(pkg,sig,pub):
    pkg=Path(pkg); sig=Path(sig); pub=Path(pub)
    expected=sha256_file(pkg)
    side=Path(str(sig)+'.json')
    if side.exists():
        meta=json.loads(side.read_text());
        if meta.get('sha256') != expected: raise SystemExit('signature verification failed: package hash mismatch')
    digest=hashlib.sha256(pkg.read_bytes()).digest()
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(digest); tmp=f.name
    try: run_openssl(['pkeyutl','-verify','-pubin','-inkey',str(pub),'-sigfile',str(sig),'-in',tmp])
    except SystemExit: raise SystemExit('signature verification failed')
    finally: os.unlink(tmp)
    print('signature valid')

def publish(root, pkg, registry, key):
    root=Path(root); pkg=Path(pkg); registry=Path(registry); registry.mkdir(parents=True,exist_ok=True)
    keys=registry/'keys'; keys.mkdir(exist_ok=True)
    pub=Path(str(key)+'.pub.pem')
    if not pub.exists():
        pub.write_bytes(run_openssl(['pkey','-in',str(key),'-pubout']))
    keyid=hashlib.sha256(pub.read_bytes()).hexdigest()[:16]
    dst=registry/pkg.name; shutil.copy2(pkg,dst)
    sig=registry/(pkg.name+'.sig'); sign(dst,key,sig)
    shutil.copy2(pub,keys/(keyid+'.pem'))
    index(registry)
    idx=json.loads((registry/'index.json').read_text())
    for e in idx['packages']:
        if e['file']==dst.name:
            e['signature']={'algorithm':'ed25519','key_id':keyid,'file':sig.name,'sha256':sha256_file(dst)}
    (registry/'index.json').write_text(json.dumps(idx,indent=2,sort_keys=True)+'\n')
    print(f'published {dst.name} key={keyid}')

def package_files(root):
    out=[]
    # Source plus language-connection assets are first-class package files.
    for tree in ('src','stdlib','pyphire','cphire','include','docs'):
        base=root/tree
        if base.is_dir():
            for p in base.rglob('*'):
                if not p.is_file(): continue
                rel=p.relative_to(root).as_posix()
                if rel.startswith('target/') or rel.startswith('build/'): continue
                out.append(rel)
    return sorted(out)

def build(root, out):
    meta=manifest(root/'seaphireinit.toml')
    out.mkdir(parents=True, exist_ok=True)
    pkg=out/f"{meta['name']}-{meta['version']}.inupkg"
    files=package_files(root)
    with zipfile.ZipFile(pkg,'w',zipfile.ZIP_DEFLATED) as z:
        z.write(root/'seaphireinit.toml','seaphireinit.toml')
        for rel in files: z.write(root/rel,rel)
        info={'format':3,'name':meta['name'],'version':meta['version'],'edition':meta['edition'],'files':files,'dependencies':meta['dependencies'],'stdlib':{'namespace':'std','root':'stdlib'},'cphire':{'abi':'native-c-abi-v1','include_root':'include'}}
        z.writestr('inupkg.json',json.dumps(info,indent=2,sort_keys=True)+'\n')
    return pkg

def read_pkg(path):
    with zipfile.ZipFile(path) as z:
        try: return json.loads(z.read('inupkg.json'))
        except KeyError: pass
        s=z.read('seaphireinit.toml').decode()
        m=re.search(r'(?m)^name\s*=\s*"([^"]+)"$',s); v=re.search(r'(?m)^version\s*=\s*"([^"]+)"$',s); e=re.search(r'(?m)^edition\s*=\s*"([^"]+)"$',s)
        return {'format':1,'name':m.group(1),'version':v.group(1),'edition':e.group(1),'dependencies':{}}

def index(reg):
    reg=Path(reg); reg.mkdir(parents=True,exist_ok=True); entries=[]
    for p in sorted(reg.glob('*.inupkg')):
        i=read_pkg(p); entry={'name':i['name'],'version':i['version'],'edition':i.get('edition',''),'file':p.name,'dependencies':i.get('dependencies',{}),'stdlib':i.get('stdlib',{})}
        sig=p.with_name(p.name+'.sig'); side=Path(str(sig)+'.json')
        if sig.exists():
            meta=json.loads(side.read_text()) if side.exists() else {}
            pub=reg/'keys'/f"{meta.get('key_id','')}.pem"
            entry['signature']={'algorithm':meta.get('algorithm','ed25519'),'key_id':meta.get('key_id',''),'file':sig.name,'sha256':meta.get('sha256',sha256_file(p))}
        entries.append(entry)
    (reg/'index.json').write_text(json.dumps({'format':2,'packages':entries},indent=2,sort_keys=True)+'\n',encoding='utf-8'); print(reg/'index.json')

def registry_candidates(reg, name):
    out=[]
    for p in Path(reg).glob(f'{name}-*.inupkg'):
        try:
            i=read_pkg(p)
            if i['name']==name: out.append((i['version'],p,i))
        except Exception: pass
    return sorted(out,key=lambda x:version(x[0]),reverse=True)

def resolve(reg, root_deps):
    constraints={k:[v] for k,v in root_deps.items()}; chosen={}; visiting=[]
    def solve(name):
        if name in visiting: raise SystemExit('dependency cycle: '+' -> '.join(visiting+[name]))
        candidates=[x for x in registry_candidates(reg,name) if all(satisfies(x[0],c) for c in constraints[name])]
        if not candidates:
            raise SystemExit(f'no version of {name} satisfies: '+', '.join(constraints[name]))
        old=chosen.get(name)
        # Highest compatible version is deterministic for this local registry.
        ver,pkg,info=candidates[0]
        if old and old[0]==ver: return
        chosen[name]=(ver,pkg,info); visiting.append(name)
        for dep,con in sorted(info.get('dependencies',{}).items()):
            constraints.setdefault(dep,[]).append(con)
            solve(dep)
        visiting.pop()
    for name in sorted(root_deps): solve(name)
    return chosen

def install(root, name, reg, constraint='*'):
    root=Path(root); reg=Path(reg); meta=manifest(root/'seaphireinit.toml')
    if name not in meta['dependencies'] and constraint=='*': constraint=meta['dependencies'].get(name,'*')
    roots=dict(meta['dependencies'])
    roots[name]=constraint if constraint!='*' else roots.get(name,'*')
    # Resolve the project graph plus the explicitly requested package.
    chosen=resolve(reg,roots)
    lock_packages={}
    for dep,(ver,pkg,info) in sorted(chosen.items()):
        dest=root/'.seaphire'/'packages'/dep/ver
        if dest.exists(): shutil.rmtree(dest)
        dest.mkdir(parents=True)
        with zipfile.ZipFile(pkg) as z:
            for n in z.namelist():
                if n in ('inupkg.json','seaphireinit.toml') or n.endswith('/'): continue
                target=dest/n; target.parent.mkdir(parents=True,exist_ok=True)
                with z.open(n) as src, target.open('wb') as dst: shutil.copyfileobj(src,dst)
        lock_packages[dep]={'version':ver,'source':str(pkg.resolve()),'dependencies':info.get('dependencies',{})}
    lock=root/'seaphire.lock'; lock.write_text(json.dumps({'format':2,'packages':lock_packages},indent=2,sort_keys=True)+'\n')
    print('resolved '+', '.join(f'{n} {v[0]}' for n,v in sorted(chosen.items())))

def uninstall(root, name):
    root=Path(root); lock=root/'seaphire.lock'
    data=json.loads(lock.read_text()) if lock.exists() else {'format':2,'packages':{}}
    if name not in data.get('packages',{}): raise SystemExit(f'package not installed: {name}')
    ver=data['packages'][name]['version']; dest=root/'.seaphire'/'packages'/name/ver
    if dest.exists(): shutil.rmtree(dest)
    data['packages'].pop(name,None)
    lock.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    print(f'uninstalled {name} {ver}')

def search(reg, query=''):
    reg=Path(reg); q=query.lower(); rows=[]
    for p in sorted(reg.glob('*.inupkg')):
        try:
            i=read_pkg(p)
            if q in i.get('name','').lower() or q in i.get('edition','').lower(): rows.append((i['name'],i['version'],i.get('edition','')))
        except Exception: pass
    for n,v,e in sorted(rows): print(f'{n} {v} ({e})')

def info(reg, name):
    for ver,p,i in registry_candidates(Path(reg),name):
        print(json.dumps(i,indent=2,sort_keys=True)); return
    raise SystemExit(f'package not found: {name}')

def list_installed(root):
    lock=Path(root)/'seaphire.lock'
    if not lock.exists(): print('no installed packages'); return
    for n,v in json.loads(lock.read_text()).get('packages',{}).items(): print(f"{n} {v['version']}")

def main():
    if len(sys.argv)<2: raise SystemExit('usage: seaphire-package.py <build|index|resolve|install|list|keygen|sign|verify|publish> ...')
    cmd=sys.argv[1]
    if cmd=='build': print(build(Path(sys.argv[2]),Path(sys.argv[3])))
    elif cmd=='index': index(sys.argv[2] if len(sys.argv)>2 else ROOT/'.seaphire-registry')
    elif cmd=='resolve':
        root=Path(sys.argv[2]) if len(sys.argv)>2 else ROOT; reg=Path(sys.argv[3]) if len(sys.argv)>3 else root/'.seaphire-registry'
        meta=manifest(root/'seaphireinit.toml'); chosen=resolve(reg,meta['dependencies'])
        print(json.dumps({n:v[0] for n,v in sorted(chosen.items())},indent=2,sort_keys=True))
    elif cmd=='install': install(Path(sys.argv[2]),sys.argv[3],sys.argv[4] if len(sys.argv)>4 else ROOT/'.seaphire-registry')
    elif cmd=='list': list_installed(Path(sys.argv[2]) if len(sys.argv)>2 else ROOT)
    elif cmd=='uninstall': uninstall(Path(sys.argv[2]) if len(sys.argv)>2 else ROOT, sys.argv[3])
    elif cmd=='search': search(Path(sys.argv[3]) if len(sys.argv)>3 else (Path(sys.argv[2]) if len(sys.argv)>2 and Path(sys.argv[2]).is_dir() else ROOT/'.seaphire-registry'), sys.argv[2] if len(sys.argv)>2 and not Path(sys.argv[2]).is_dir() else '')
    elif cmd=='info': info(Path(sys.argv[3]) if len(sys.argv)>3 else ROOT/'.seaphire-registry', sys.argv[2])
    elif cmd=='keygen': keygen(sys.argv[2])
    elif cmd=='sign': sign(sys.argv[2],sys.argv[3],sys.argv[4] if len(sys.argv)>4 else None)
    elif cmd=='verify': verify(sys.argv[2],sys.argv[3],sys.argv[4])
    elif cmd=='publish': publish(Path(sys.argv[2]),Path(sys.argv[3]),Path(sys.argv[4]),Path(sys.argv[5]))
    else: raise SystemExit('unknown package command')

if __name__=='__main__': main()
