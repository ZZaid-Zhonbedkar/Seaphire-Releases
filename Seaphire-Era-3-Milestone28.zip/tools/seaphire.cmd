@echo off
setlocal
set ROOT=%~dp0..
set COMPILER=%ROOT%build\seaphirec.exe
if "%1"=="build" goto build
if "%1"=="check" goto check
if "%1"=="run" goto run
if "%1"=="init" goto init
echo Seaphire Era 2 Delta
echo Usage: seaphire.cmd init ^| check file.inu ^| run file.inu ^| build
exit /b 2
:build
if not exist "%ROOT%build" mkdir "%ROOT%build"
rustc "%ROOT%seaphirec\src\main.rs" -o "%COMPILER%"
echo built Seaphire reference compiler
exit /b %errorlevel%
:check
if not exist "%ROOT%build" mkdir "%ROOT%build"
rustc "%ROOT%seaphirec\src\main.rs" -o "%COMPILER%"
"%COMPILER%" %2 >nul
if errorlevel 1 exit /b 1
echo check passed: %2
exit /b 0
:run
if not exist "%ROOT%build" mkdir "%ROOT%build"
rustc "%ROOT%seaphirec\src\main.rs" -o "%COMPILER%"
if "%2"=="" ("%COMPILER%" "%ROOT%src\main.inu") else ("%COMPILER%" "%2")
exit /b %errorlevel%
:init
if not exist "%ROOT%src" mkdir "%ROOT%src"
if not exist "%ROOT%seaphireinit.toml" echo [project]>"%ROOT%seaphireinit.toml"
exit /b 0
