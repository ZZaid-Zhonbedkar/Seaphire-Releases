#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
REG="$TMP/registry"
mkdir -p "$REG"
KEY="$TMP/publisher.pem"
./tools/seaphire package keygen "$KEY" >/dev/null
PKG="$TMP/package.inupkg"
./tools/seaphire package build "$TMP/out" >/dev/null
cp "$ROOT/$ROOT/target/package/seaphire-era-2-delta-os-3.0.0-alpha.3.inupkg" "$PKG" 2>/dev/null || cp "$ROOT/target/package/seaphire-era-2-delta-os-3.0.0-alpha.3.inupkg" "$PKG"
./tools/seaphire package sign "$PKG" "$KEY" >/dev/null
./tools/seaphire package verify "$PKG" "$PKG.sig" "$KEY.pub.pem" >/dev/null
./tools/seaphire package publish "$PKG" "$REG" "$KEY" >/dev/null
[ -f "$REG/package.inupkg" ]
[ -f "$REG/package.inupkg.sig" ]
[ -f "$REG/keys/$(python3 - "$KEY.pub.pem" <<'PY'
import hashlib,sys
print(hashlib.sha256(open(sys.argv[1],'rb').read()).hexdigest()[:16])
PY
).pem" ]
python3 - "$PKG" <<'PY'
import sys
p=sys.argv[1]
b=bytearray(open(p,'rb').read()); b[-1]^=1; open(p,'wb').write(b)
PY
if ./tools/seaphire package verify "$PKG" "$PKG.sig" "$KEY.pub.pem" >/dev/null 2>&1; then
  echo "tamper detection failed" >&2; exit 1
fi
echo "era3 package signing passed"
