#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
rm -rf target/m28-cphire .seaphire/packages/cphire seaphire.lock
python3 tools/seaphire-package.py build packages/cphire-0.1.0 target/m28-cphire >/dev/null
cp target/m28-cphire/cphire-0.1.0.inupkg .seaphire-registry/cphire-0.1.0.inupkg
./tools/seaphire package index .seaphire-registry >/dev/null
./tools/sea install cphire .seaphire-registry >/dev/null
TMP=$(mktemp -d /tmp/seaphire-m28-cphire.XXXXXX)
trap 'rm -rf "$TMP"; rm -rf target/m28-cphire .seaphire/packages/cphire seaphire.lock' EXIT
cat > "$TMP/main.inu" <<'INU'
IMPORT cphire::cphire_add_i64
FUNC main() -> int {
    int value = cphire_add_i64(40, 2)
    PRINT value
    RET value
}
INU
cat > "$TMP/add.c" <<'C'
#include <stdint.h>
int64_t cphire_add_i64(int64_t a, int64_t b) { return a + b; }
C
./tools/sea c build "$TMP/main.inu" "$TMP/add.c" -o "$TMP/app" >/dev/null
set +e
"$TMP/app" >/tmp/m28-cphire-output
rc=$?
set -e
[ "$rc" -eq 42 ]
[ "$(cat /tmp/m28-cphire-output)" = "42" ]
rm -f /tmp/m28-cphire-output
echo 'm28 cphire passed'
