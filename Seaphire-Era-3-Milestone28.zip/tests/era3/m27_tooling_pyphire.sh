#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
cd "$ROOT"
rm -rf .seaphire seaphire.lock target/m27
mkdir -p target/m27
./tools/seaphire package index .seaphire-registry >/dev/null
./tools/sea install pyphire .seaphire-registry >/dev/null
./tools/sea search pyphire .seaphire-registry | grep -q '^pyphire 0.1.0'
./tools/sea info pyphire .seaphire-registry >/tmp/pyphire-info.json
python3 - <<'PY'
import json
x=json.load(open('/tmp/pyphire-info.json'))
assert x['name']=='pyphire' and x['version']=='0.1.0'
PY
python3 - <<'PY'
import sys
sys.path.insert(0,'.seaphire/packages/pyphire/0.1.0')
from pyphire import call, protocol_version
assert protocol_version()=='json-lines-v1'
assert call('math.sqrt',81)==9.0
print('pyphire python bridge passed')
PY
cat > target/m27/pyphire_import.inu <<'INU'
IMPORT pyphire::pyphire_api_version
FUNC main() -> int {
    int v = pyphire_api_version()
    RET v
}
INU
./tools/sea fmt target/m27/pyphire_import.inu >/dev/null
./tools/sea lint target/m27/pyphire_import.inu >/dev/null
./tools/sea symbols target/m27/pyphire_import.inu | grep -q 'main'
./tools/seaphire test-native >/dev/null
./build/native/seaphirec-native target/m27/pyphire_import.inu target/m27/pyphire_import >/dev/null
set +e
target/m27/pyphire_import >/dev/null
rc=$?
set -e
[ "$rc" -eq 1 ]
./tools/seaphire package uninstall pyphire >/dev/null
! test -d .seaphire/packages/pyphire
printf '%s\n' 'era3 m27 tooling + pyphire workflow passed'
