#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
TMP="$ROOT/target/era3-m24-import"
rm -rf "$TMP"; mkdir -p "$TMP/src" "$TMP/.seaphire/packages/hello-lib/0.1.0/src"
cat > "$TMP/seaphire.lock" <<'EOF'
{"format":2,"packages":{"hello-lib":{"version":"0.1.0","source":"local","dependencies":{}}}}
EOF
cat > "$TMP/.seaphire/packages/hello-lib/0.1.0/src/hello.inu" <<'EOF'
FUNC hello_value() -> int {
    RET 42
}
EOF
cat > "$TMP/src/main.inu" <<'EOF'
IMPORT hello-lib::hello_value
FUNC main() -> int {
    int value = hello_value()
    RET value
}
EOF
cc -O2 "$ROOT/nativec/src/seaphirec_native.c" -o "$TMP/core"
cp "$ROOT/nativec/src/seaphirec-native-wrapper.sh" "$TMP/compiler"
cp "$ROOT/nativec/src/seaphire_v2.py" "$TMP/seaphire_v2.py"
cp "$ROOT/nativec/src/og_seaphire.py" "$TMP/og_seaphire.py"
cp "$ROOT/nativec/src/struct_lower.py" "$TMP/struct_lower.py"
chmod +x "$TMP/compiler"
# Use the real built compiler path so PROJECT_ROOT points at the project.
mkdir -p "$ROOT/build/native"
cp "$TMP/core" "$ROOT/build/native/seaphirec-native-core"
cp "$ROOT/nativec/src/seaphirec-native-wrapper.sh" "$ROOT/build/native/seaphirec-native"
cp "$ROOT/nativec/src/seaphire_v2.py" "$ROOT/build/native/seaphire_v2.py"
cp "$ROOT/nativec/src/og_seaphire.py" "$ROOT/build/native/og_seaphire.py"
cp "$ROOT/nativec/src/struct_lower.py" "$ROOT/build/native/struct_lower.py"
chmod +x "$ROOT/build/native/seaphirec-native"
"$ROOT/build/native/seaphirec-native" "$TMP/src/main.inu" "$TMP/app"
set +e
"$TMP/app" >/dev/null
rc=$?
set -e
[ "$rc" -eq 42 ]
echo 'era3 namespace import passed'
