#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
REG="$ROOT/.seaphire-registry"
rm -rf "$ROOT/.seaphire" "$ROOT/seaphire.lock"
"$ROOT/tools/seaphire" package check >/dev/null
PKG=$($ROOT/tools/seaphire package build | tail -n 1)
test -f "$PKG"
python3 "$ROOT/tools/seaphire-package.py" build "$ROOT/packages/hello-lib-0.1.0" "$REG" >/dev/null
$ROOT/tools/seaphire package index "$REG" >/dev/null
$ROOT/tools/seaphire package install hello-lib "$REG" >/dev/null
$ROOT/tools/seaphire package list | grep -qx 'hello-lib 0.1.0'
test -f "$ROOT/.seaphire/packages/hello-lib/0.1.0/src/hello.inu"
echo "era3 package workflow passed"
