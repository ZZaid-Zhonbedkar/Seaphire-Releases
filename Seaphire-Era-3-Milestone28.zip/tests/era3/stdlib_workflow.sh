#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
rm -rf "$ROOT/target/m26-stdlib" "$ROOT/build/native/m26-stdlib"
mkdir -p "$ROOT/target/m26-stdlib"
"$ROOT/tools/seaphire" package check >/dev/null
"$ROOT/tools/seaphire" package build "$ROOT/target/m26-stdlib" >/dev/null
PKG="$ROOT/target/m26-stdlib/seaphire-era-2-delta-os-3.0.0-alpha.3.inupkg"
test -f "$PKG"
python3 - "$PKG" <<'PY'
import json,sys,zipfile
with zipfile.ZipFile(sys.argv[1]) as z:
    m=json.loads(z.read('inupkg.json'))
    assert m['format']==3
    assert m['stdlib']['namespace']=='std'
    assert 'stdlib/core/prelude.inu' in m['files']
    assert 'stdlib/path/path.inu' in m['files']
print('stdlib package metadata passed')
PY
"$ROOT/tools/seaphire" test-native >/dev/null
OUT="$ROOT/build/native/m26-stdlib"
"$ROOT/build/native/seaphirec-native" "$ROOT/nativec/tests/m26_stdlib.inu" "$OUT" >/dev/null
LINES=$("$OUT" | wc -l)
test "$LINES" -eq 7
printf '%s\n' 'era3 stdlib workflow passed'
