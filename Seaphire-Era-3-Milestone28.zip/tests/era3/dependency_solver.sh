#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
TMP="$ROOT/target/era3-m24-test"
REG="$TMP/registry"
rm -rf "$TMP"; mkdir -p "$REG"
makepkg() {
  d="$TMP/$1"; mkdir -p "$d/src"
  cat > "$d/seaphireinit.toml" <<EOF
[package]
name = "$1"
version = "$2"
edition = "era3"
[dependencies]
$3
EOF
  cat > "$d/src/lib.inu" <<EOF
FUNC $4() -> int {
    RET 1
}
EOF
  python3 "$ROOT/tools/seaphire-package.py" build "$d" "$REG" >/dev/null
}
makepkg core-lib 1.0.0 '' core_value
makepkg core-lib 1.2.0 '' core_value
makepkg util-lib 1.0.0 'core-lib = "^1.0.0"' util_value
makepkg bad-lib 1.0.0 'core-lib = ">=2.0.0"' bad_value
cat > "$TMP/seaphireinit.toml" <<'EOF'
[package]
name = "app"
version = "0.1.0"
edition = "era3"
[dependencies]
util-lib = "^1.0.0"
EOF
python3 "$ROOT/tools/seaphire-package.py" index "$REG" >/dev/null
python3 "$ROOT/tools/seaphire-package.py" resolve "$TMP" "$REG" | grep -q '"core-lib": "1.2.0"'
python3 "$ROOT/tools/seaphire-package.py" install "$TMP" util-lib "$REG" | grep -q 'core-lib 1.2.0'
[ "$(python3 -c 'import json; print(json.load(open("'$TMP'/seaphire.lock"))["packages"]["util-lib"]["version"])')" = "1.0.0" ]
# Deterministic lock ordering.
python3 "$ROOT/tools/seaphire-package.py" install "$TMP" util-lib "$REG" >/dev/null
cmp "$TMP/seaphire.lock" "$TMP/seaphire.lock"
# Incompatible graph must fail.
cat > "$TMP/seaphireinit.toml" <<'EOF'
[package]
name = "app"
version = "0.1.0"
edition = "era3"
[dependencies]
bad-lib = "1.0.0"
EOF
if python3 "$ROOT/tools/seaphire-package.py" resolve "$TMP" "$REG" >/dev/null 2>&1; then exit 1; fi
echo 'era3 dependency solver passed'
