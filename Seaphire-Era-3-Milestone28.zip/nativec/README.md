# Seaphire native compiler — Milestone 10

`seaphirec-native` is the native backend for Seaphire Era 2 Delta.

Build it with:

```sh
make -C nativec
```

Or:

```sh
./tools/seaphire build --native
```

The Milestone 10 slice supports `i64`, `bool`, `str`, immutable-by-default
locals, typed local references (`&i64`, `&mut i64`, `*ref`), conservative
ownership/borrow checking, owned `box_i64` values, real owned `slice_i64`
values, checked slice indexing, comparisons, `if`/`else`, `while`, functions,
calls, `println`, and `return`.

## Owned slices

```inu
let s: slice_i64 = slice_i64(3);
let z: i64 = slice_set(s, 0, 11);
println slice_at(s, 0);
println slice_len(s);
let t: slice_i64 = move_slice(s);
return free_slice(t);
```

`slice_i64` is represented by an owned pointer+length header with contiguous
i64 storage. `slice_at` and `slice_set` perform bounds checks. `move_slice`
transfers ownership and the compiler rejects later uses of the moved local.

The compiler lowers through a typed linear IR with explicit control-flow
instructions and a verifier before x86_64 assembly is emitted.


## Milestone 11: borrowed slices

The native backend now supports `&slice_i64` and `&mut slice_i64` as non-owning references, including function parameters and checked `slice_ref_len`, `slice_ref_at`, and `slice_ref_set` operations. Borrow conflicts are rejected conservatively.

## Milestone 13

Heap structs use `box Type { ... }`, `move value`, field access, and automatic drop. The current implementation lowers heap structs to the existing owned `slice_i64` runtime representation while preserving ownership checks.


## Milestone 14: nested and aggregate structs

Nested structs now receive an explicit 8-byte-aligned aggregate layout. Heap
aggregates can contain nested structs plus owning `slice_i64` and `box_i64`
fields. Reading an owning heap field moves it out and clears the aggregate slot
so automatic cleanup cannot double-free it.
