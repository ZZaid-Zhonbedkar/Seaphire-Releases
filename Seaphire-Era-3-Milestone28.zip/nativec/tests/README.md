
Milestone 14 aggregate tests cover nested stack/heap structs and owning slice/box fields.

### Generic functions (Milestone 19)

- `generic_identity.inu` — generic identity specialization
- `generic_add.inu` — generic arithmetic specialization
- `generic_bad_type.inu` — unsupported generic type diagnostic
