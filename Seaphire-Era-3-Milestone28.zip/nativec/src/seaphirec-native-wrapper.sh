#!/bin/sh
set -eu
D=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PROJECT_ROOT=$(CDPATH= cd -- "$D/../.." && pwd)
INPUT="$1"
OUTPUT="$2"
shift 2
P=$(CDPATH= cd -- "$(dirname -- "$INPUT")" && pwd)
while [ "$P" != "/" ]; do
 if [ -f "$P/seaphire.lock" ]; then PROJECT_ROOT="$P"; break; fi
 P=$(dirname -- "$P")
done
if grep -Eq '^[[:space:]]*IMPORT[[:space:]]+' "$INPUT"; then
 t=$(mktemp /tmp/seaphire-imports.XXXXXX.inu); trap 'rm -f "$t"' EXIT
 python3 "$D/../../tools/seaphire-imports.py" "$PROJECT_ROOT" "$INPUT" "$t"
 INPUT="$t"
fi
if grep -Eq '^_MAIN:' "$INPUT"; then
 t=$(mktemp /tmp/seaphire-og.XXXXXX.inu); trap 'rm -f "$t"' EXIT
 python3 "$D/og_seaphire.py" "$INPUT" "$t"
 exec "$D/seaphirec-native-core" "$t" "$OUTPUT" "$@"
fi
if grep -Eq '^([[:space:]]*FUNC[[:space:]]+[A-Za-z_][A-Za-z0-9_]*|[[:space:]]*int[[:space:]]+[A-Za-z_][A-Za-z0-9_]*[[:space:]]*\()' "$INPUT"; then
 t=$(mktemp /tmp/seaphire-v2.XXXXXX.inu); trap 'rm -f "$t"' EXIT
 python3 "$D/seaphire_v2.py" "$INPUT" "$t"
 if grep -Eq '(^|[^[:alnum:]_])struct[[:space:]]+[A-Za-z_][A-Za-z0-9_]*[[:space:]]*\{' "$t"; then
  a=$(mktemp /tmp/seaphire-v2-struct.XXXXXX.inu)
  python3 "$D/struct_lower.py" "$t" "$a"
  exec "$D/seaphirec-native-core" "$a" "$OUTPUT" "$@"
 fi
 exec "$D/seaphirec-native-core" "$t" "$OUTPUT" "$@"
fi
if grep -Eq '(^|[^[:alnum:]_])struct[[:space:]]+[[:alnum:]_]+[[:space:]]*\{' "$INPUT"; then
 t=$(mktemp /tmp/seaphire-struct.XXXXXX.inu); trap 'rm -f "$t"' EXIT
 python3 "$D/struct_lower.py" "$INPUT" "$t"
 exec "$D/seaphirec-native-core" "$t" "$OUTPUT" "$@"
fi
exec "$D/seaphirec-native-core" "$INPUT" "$OUTPUT" "$@"
