#!/usr/bin/env python3
"""Seaphire OG syntax bridge: assembly-inspired source -> Era 2 native syntax.
This is intentionally a compatibility frontend, not the language backend.
"""
import re, sys

def split_args(s):
    return [x.strip() for x in re.split(r'\s+', s.strip()) if x.strip()]

def val(x):
    x=x.strip()
    if re.fullmatch(r'-?\d+', x) or x in ('true','false') or (len(x)>=2 and x[0]=='"' and x[-1]=='"'):
        return x
    return x

def translate(src):
    lines=src.splitlines(); out=[]; in_main=False; vars={}; pending_vars=[]; indent=0; var_count=None; implicit_if=False
    def emit(s): out.append('    '*indent+s)
    for raw in lines:
        line=raw.strip()
        if not line or line.startswith('crap->') or line.startswith('//'): continue
        if line.startswith('_VARS:'):
            try: var_count=int(line.split(':',1)[1].strip())
            except: var_count=None
            continue
        if line=='_MAIN:':
            in_main=True; emit('fn main() -> i64 {'); indent+=1;
            for n,v in pending_vars: emit(f'let mut {n}: i64 = {v};')
            pending_vars.clear(); continue
        if line=='_END:':
            while indent>1: indent-=1; emit('}')
            if indent>0: indent-=1
            if in_main: emit('return 0;'); emit('}'); in_main=False
            continue
        if not in_main and not (line.startswith('@') or re.match(r'^(int|float|str|bool)\s+', line)): continue
        if line=='{': emit('{'); indent+=1; continue
        if line=='}': indent=max(0,indent-1); emit('}'); continue
        if line.startswith('@') or re.match(r'^(int|float|str|bool)\s+', line):
            m=re.match(r'^@?(int|float|str|bool)\s+([^\s]+)\s+(.+)$',line)
            if not m: raise ValueError('bad variable declaration: '+line)
            typ,name,value=m.groups();
            if name.startswith('?'): name=name[1:]
            if typ!='int': raise ValueError('Milestone 15 native bridge currently supports int variables only')
            vars[name]=True
            if in_main: emit(f'let mut {name}: i64 = {val(value)};')
            else: pending_vars.append((name,val(value)))
            continue
        parts=split_args(line)
        if not parts: continue
        op=parts[0].upper(); args=parts[1:]
        if op=='MOV' and len(args)>=2:
            dst=args[0].rstrip(','); rhs=' '.join(args[1:]).replace(',', ' ');
            if dst not in vars: vars[dst]=True; emit(f'let mut {dst}: i64 = {val(rhs)};')
            else: emit(f'{dst} = {val(rhs)};')
        elif op in ('ADD','SUB','MUL','DIV') and len(args)>=2:
            dst=args[0].rstrip(','); rhs=' '.join(args[1:]).replace(',', ' '); sym={'ADD':'+','SUB':'-','MUL':'*','DIV':'/'}[op]
            if dst not in vars: raise ValueError(f'unknown destination {dst}')
            emit(f'{dst} = {dst} {sym} {val(rhs)};')
        elif op=='PRINT' or op=='PRINT_COOL':
            emit('println '+(' '.join(args).replace(',', ' '))+';')
        elif op=='DEL' and args:
            # OG DEL is retained as a recognized no-op compatibility instruction for now.
            emit('// DEL '+args[0])
        elif op=='IF':
            cond=' '.join(args)
            if cond.startswith('[') and cond.endswith(']'): cond=cond[1:-1]
            emit(f'if {cond} {{'); indent+=1; implicit_if=True
        elif op=='ELIF':
            indent=max(0,indent-1); cond=' '.join(args).strip('[]'); emit(f'}} else if {cond} {{'); indent+=1
        elif op=='ELSE':
            indent=max(0,indent-1); emit('} else {'); indent+=1
        elif op=='LOOP':
            # LOOP label -> while true; JUMPIF can terminate via a translated condition in later revisions.
            emit('while true {'); indent+=1
        elif op=='JUMPIF':
            # Basic compatibility: JUMPIF <n> [cond] becomes conditional return for now.
            cond=' '.join(args[1:]).strip('[]') if len(args)>=2 else 'false'
            emit(f'if {cond} {{ return 0; }}')
        elif op=='RET' or op=='RETURN':
            emit('return '+(' '.join(args) if args else '0')+';')
        else:
            raise ValueError('unsupported OG instruction: '+line)
    if in_main: raise ValueError('missing _END:')
    return '\n'.join(out)+'\n'

if __name__=='__main__':
    if len(sys.argv)!=3:
        print('usage: og_seaphire.py input.inu output.inu',file=sys.stderr); sys.exit(2)
    try:
        with open(sys.argv[1],encoding='utf-8') as f: src=f.read()
        out=translate(src)
        with open(sys.argv[2],'w',encoding='utf-8') as f:f.write(out)
    except Exception as e:
        print('seaphire OG frontend:',e,file=sys.stderr);sys.exit(1)
