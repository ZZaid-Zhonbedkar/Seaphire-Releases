#!/usr/bin/env python3
"""Seaphire Syntax v2 compatibility frontend.

Syntax v2 is structured/C-like around the edges and assembly-inspired inside blocks.
Milestone 18 adds a first-class tagged-union IR layer, explicit tag/payload operations, and MATCH exhaustiveness checking.
Milestone 19 adds source-level generic functions with compile-time monomorphization.
Milestone 20 adds generic aggregate structs with compile-time specialization.

The native i64 backend still lowers tagged values to a compact host ABI at the final lowering boundary; Seaphire source semantics no longer depend on that representation.
"""
import re, sys

def split_top(s):
    out=[]; cur=''; depth=0; quote=False
    for c in s:
        if c=='"' and (not cur or cur[-1] != '\\'): quote=not quote
        if not quote:
            if c in '([{': depth+=1
            elif c in ')]}': depth-=1
            if c==',' and depth==0:
                out.append(cur.strip()); cur=''; continue
        cur+=c
    if cur.strip(): out.append(cur.strip())
    return out

def parse_enums(src):
    enums={}; payload={}; clean=[]; lines=src.splitlines(); i=0
    while i < len(lines):
        line=lines[i].strip()
        m=re.match(r'^ENUM\s+([A-Za-z_]\w*)\s*\{\s*$',line,re.I)
        if not m:
            clean.append(lines[i]); i+=1; continue
        en=m.group(1); i+=1; tag=0
        while i < len(lines):
            x=lines[i].strip()
            if x=='}': i+=1; break
            x=x.rstrip(',').strip()
            if not x: i+=1; continue
            vm=re.match(r'^([A-Za-z_]\w*)\s*(?:\(([^)]*)\))?$',x)
            if not vm: raise ValueError('bad ENUM variant: '+x)
            name,args=vm.groups();
            if name in enums: raise ValueError('duplicate enum variant: '+name)
            enums[name]=tag; payload[name]=bool(args and args.strip()); tag+=1; i+=1
        else: raise ValueError('unterminated ENUM '+en)
    return clean,enums,payload

def expand_generic_structs(lines):
    """Expand STRUCT Name<T> declarations into concrete backend structs.

    The aggregate backend currently stores machine-word fields, so generic
    struct parameters are specialized to i64/int (and can be used in ordinary
    scalar fields). The source type remains generic; the backend sees a normal
    concrete struct after this compile-time pass.
    """
    base=[]; templates={}; i=0
    while i < len(lines):
        line=lines[i]
        m=re.match(r'^\s*STRUCT\s+([A-Za-z_]\w*)\s*<\s*([^>]+)\s*>\s*\{\s*$', line, re.I)
        if not m:
            base.append(line); i+=1; continue
        name,params=m.groups(); params=[x.strip() for x in split_top(params)]
        if not params or any(not re.match(r'^[A-Za-z_]\w*$',x) for x in params):
            raise ValueError('invalid generic STRUCT parameter list for '+name)
        body=[]; depth=1; i+=1
        while i < len(lines):
            x=lines[i]; depth += x.count('{')-x.count('}')
            if depth<=0: break
            body.append(x); i+=1
        if depth!=0: raise ValueError('unterminated generic STRUCT '+name)
        templates[name]=(params,body); i+=1

    requests=[]; seen=set()
    def scan(text):
        for m in re.finditer(r'\b([A-Za-z_]\w*)\s*<\s*([^>]+?)\s*>', text):
            name=m.group(1); tys=tuple(x.strip() for x in split_top(m.group(2)))
            if name in templates and (name,tys) not in seen:
                seen.add((name,tys)); requests.append((name,tys))
    for x in base: scan(x)

    generated=[]; idx=0
    while idx < len(requests):
        name,tys=requests[idx]; idx+=1
        params,body=templates[name]
        if len(tys)!=len(params):
            raise ValueError(f'{name} expects {len(params)} type argument(s), got {len(tys)}')
        if any(t.lower() not in ('int','i64') for t in tys):
            raise ValueError('generic STRUCT instantiations currently support only int/i64: '+name)
        concrete=name+'_'+'_'.join('i64' for _ in tys)
        subst=dict(zip(params,['i64']*len(tys)))
        generated.append(f'struct {concrete} {{')
        for b in body:
            y=b
            for gp,ct in subst.items():
                y=re.sub(r'\b'+re.escape(gp)+r'\b',ct,y)
            generated.append(y)
            scan(y)
        generated.append('}')
    out=[]
    for x in base:
        y=x
        for name,tys in requests:
            concrete=name+'_'+'_'.join('i64' for _ in tys)
            y=re.sub(r'\b'+re.escape(name)+r'\s*<\s*'+r'\s*,\s*'.join(r'[^>]+?' for _ in tys)+r'\s*>', concrete, y)
        out.append(y)
    return generated+out

def parse_generics(lines):
    """Collect generic FUNC declarations and expand their call names.

    Era 2 native backend currently has an i64 scalar ABI, so Milestone 19
    deliberately supports scalar generic parameters instantiated as int/i64.
    The frontend still performs real source-level monomorphization: each used
    specialization gets a distinct internal function name.
    """
    generics={}
    for line in lines:
        m=re.match(r'^FUNC\s+([A-Za-z_]\w*)\s*<([^>]+)>\s*\((.*?)\)\s*(?:->\s*([^\s{]+))?\s*\{\s*$', line.strip(), re.I)
        if not m: continue
        name,types,args,ret=m.groups()
        params=[x.strip() for x in split_top(types) if x.strip()]
        if not params or any(not re.match(r'^[A-Za-z_]\w*$', x) for x in params):
            raise ValueError('invalid generic parameter list for '+name)
        if any(a for a in params if a.lower() in ('int','i64','bool','str')):
            raise ValueError('generic parameters must be type names, not concrete types')
        generics[name]={'types':params,'args':args,'ret':ret or 'int'}
    return generics

def monomorph_name(name, types):
    safe='_'.join(re.sub(r'[^A-Za-z0-9_]', '_', t) for t in types)
    return f'__seaphire_generic_{name}_{safe}'

class TaggedIR:
    def __init__(self):
        self.ops=[]
    def construct(self, variant, tag, payload_expr=None):
        self.ops.append(("TAGGED_CONSTRUCT", variant, tag, payload_expr))
        return ("tagged", variant, tag, payload_expr)
    def tag(self, value):
        self.ops.append(("TAGGED_TAG", value))
        return ("tag", value)
    def payload(self, value):
        self.ops.append(("TAGGED_PAYLOAD", value))
        return ("payload", value)

def match_exhaustive(variants, cases, has_default):
    if has_default: return
    missing=[v for v in variants if v not in cases]
    if missing:
        raise ValueError("non-exhaustive MATCH; missing: " + ", ".join(missing))

def lower_expr(x,enums,payload):
    x=x.strip()
    # array indexing
    x=re.sub(r'\b([A-Za-z_]\w*)\s*\[\s*([^\]]+)\s*\]',r'slice_at(\1, \2)',x)
    # First-class tagged-union construction. The final backend lowering keeps
    # the representation compact, but source semantics are expressed as tag
    # + optional payload operations first.
    def ctor(m):
        name,arg=m.group(1),m.group(2)
        if name not in enums: return m.group(0)
        tag=enums[name]
        ir=TaggedIR()
        if payload[name]:
            if arg is None or not arg.strip(): raise ValueError(name+' requires a payload')
            ir.construct(name, tag, lower_expr(arg,enums,payload))
            return f'(({lower_expr(arg,enums,payload)}) * 1000000 + {tag})'
        if arg and arg.strip(): raise ValueError(name+' takes no payload')
        ir.construct(name, tag, None)
        return str(tag)
    x=re.sub(r'\b([A-Za-z_]\w*)\s*\(([^()]*)\)',ctor,x)
    for name,tag in enums.items(): x=re.sub(r'\b'+re.escape(name)+r'\b',str(tag),x)
    return x

def expand_generics(lines):
    """Monomorphize generic FUNC blocks into ordinary Syntax v2 functions.

    Milestone 19 intentionally starts with scalar instantiations supported by
    the native Era 2 ABI: int/i64. This is a real compile-time expansion, not
    a runtime generic mechanism. The design leaves room for later aggregate
    instantiations once the native ABI grows them.
    """
    base=[]; templates={}; i=0
    while i < len(lines):
        line=lines[i]
        m=re.match(r'^\s*FUNC\s+([A-Za-z_]\w*)\s*<([^>]+)>\s*\((.*?)\)\s*(?:->\s*(\w+))?\s*\{\s*$', line, re.I)
        if not m:
            base.append(line); i+=1; continue
        name,types,args,ret=m.groups()
        params=[x.strip() for x in split_top(types) if x.strip()]
        if not params or any(not re.match(r'^[A-Za-z_]\w*$', x) for x in params):
            raise ValueError('invalid generic parameter list for '+name)
        body=[]; depth=1; i+=1
        while i < len(lines):
            x=lines[i]
            # Syntax v2 function bodies are line-brace structured; count braces
            # outside strings, which is sufficient for the supported surface.
            opens=x.count('{'); closes=x.count('}')
            depth += opens - closes
            if depth <= 0:
                break
            body.append(x); i+=1
        if depth != 0: raise ValueError('unterminated generic FUNC '+name)
        templates[name]={'types':params,'args':args,'ret':ret or 'int','body':body}
        i+=1

    # Find every explicit instantiation in the non-generic program.
    requested=[]
    seen=set()
    def scan(text):
        for m in re.finditer(r'\b([A-Za-z_]\w*)\s*<\s*([^>]+?)\s*>\s*\(', text):
            name=m.group(1); tys=tuple(x.strip() for x in split_top(m.group(2)))
            if name not in templates: continue
            key=(name,tys)
            if key not in seen:
                seen.add(key); requested.append(key)
    for x in base: scan(x)

    generated=[]; idx=0
    while idx < len(requested):
        name,tys=requested[idx]; idx+=1
        t=templates[name]
        if len(tys)!=len(t['types']):
            raise ValueError(f'{name} expects {len(t["types"])} type argument(s), got {len(tys)}')
        if any(x.lower() not in ('int','i64') for x in tys):
            raise ValueError('generic instantiations currently support only int/i64: '+name)
        subst=dict(zip(t['types'], ['i64']*len(tys)))
        concrete=monomorph_name(name, tys)
        params=[]
        for a in split_top(t['args']):
            if not a: continue
            am=re.match(r'^([A-Za-z_]\w*)\s*:\s*(.+)$',a)
            if am:
                pn,pt=am.groups(); pt=subst.get(pt.strip(),pt.strip())
                if pt not in ('int','i64'): raise ValueError('unsupported generic parameter type '+pt)
                params.append(f'{pn}: i64')
            else:
                params.append(f'{a}: i64')
        ret=subst.get(t['ret'].strip(), t['ret'].strip())
        if ret not in ('int','i64'): ret='i64'
        generated.append(f'FUNC {concrete}({", ".join(params)}) -> {ret} {{')
        for b in t['body']:
            y=b
            for gp,ct in subst.items():
                y=re.sub(r'\b'+re.escape(gp)+r'\b',ct,y)
            # Nested generic calls inside a generated body are also discovered.
            scan(y)
            y=re.sub(r'\b'+re.escape(name)+r'\s*<\s*([^>]+?)\s*>\s*\(', lambda m: monomorph_name(name, tuple(x.strip() for x in split_top(m.group(1))))+'(', y)
            generated.append(y)
        generated.append('}')
    # Rewrite explicit calls in ordinary source to their monomorphized symbols.
    out=[]
    for x in base:
        def rw(m):
            name=m.group(1); tys=tuple(v.strip() for v in split_top(m.group(2)))
            if name not in templates: return m.group(0)
            return monomorph_name(name,tys)+'('
        out.append(re.sub(r'\b([A-Za-z_]\w*)\s*<\s*([^>]+?)\s*>\s*\(',rw,x))
    # Generic specializations are appended before the user functions; both are
    # legal to call because the downstream frontend has no declaration-order rule.
    return generated + out

def translate(src):
    raw_lines=src.splitlines()
    raw_lines=expand_generic_structs(raw_lines)
    raw_lines=expand_generics(raw_lines)
    lines,enums,payload=parse_enums('\n'.join(raw_lines))
    out=[]; funcs=0; arrays=set(); tmp=0; match_stack=[]; active_binding=None; struct_depth=0
    def emit(s): out.append(s)
    def ex(s): return lower_expr(s,enums,payload)
    for raw in lines:
        line=raw.strip()
        if active_binding and not re.match(r'^(CASE|DEFAULT|MATCH)\b', line, re.I):
            line=re.sub(r'\b'+re.escape(active_binding[0])+r'\b', active_binding[1], line)
        if not line or line.startswith('//'): continue
        if struct_depth:
            emit(raw)
            struct_depth += raw.count('{') - raw.count('}')
            continue
        if re.match(r'^struct\s+[A-Za-z_]\w*\s*\{\s*$', line, re.I):
            emit(raw)
            struct_depth = 1
            continue
        # C ABI declarations: EXTERN FUNC name(A: int, B: int) -> int;
        m=re.match(r'^EXTERN\s+FUNC\s+([A-Za-z_]\w*)\s*\((.*?)\)\s*(?:->\s*(\w+))?\s*;\s*$',line,re.I)
        if m:
            name,args,ret=m.groups(); params=[]
            for a in split_top(args):
                if not a: continue
                am=re.match(r'^([A-Za-z_]\w*)\s*:\s*(.+)$',a)
                pt=am.group(2).strip() if am else 'i64'
                if pt.lower()=='int': pt='i64'
                params.append(f'{am.group(1)}: {pt}' if am else f'{a}: {pt}')
            rr=ret or 'i64'
            if rr.lower()=='int': rr='i64'
            emit(f'extern fn {name}({", ".join(params)}) -> {rr};'); continue
        m=re.match(r'^extern\s+(?:int|i64)\s+([A-Za-z_]\w*)\s*\((.*?)\)\s*;\s*$',line,re.I)
        if m:
            name,args=m.groups(); params=[]
            for a in split_top(args):
                if not a: continue
                am=re.match(r'^([A-Za-z_]\w*)\s*:\s*(.+)$',a)
                params.append(f'{am.group(1)}: {am.group(2)}' if am else f'{a}: i64')
            emit(f'extern fn {name}({", ".join(params)}) -> i64;'); continue
        # function declarations
        m=re.match(r'^([A-Za-z_]\w*)\s+([A-Za-z_]\w*)\s*\((.*?)\)\s*\{\s*$',line,re.I)
        if m and m.group(1).lower() in ('int','i64'):
            _,name,args=m.groups(); params=[]
            for a in split_top(args):
                if not a: continue
                am=re.match(r'^([A-Za-z_]\w*)\s*:\s*(.+)$',a)
                params.append(f'{am.group(1)}: {am.group(2)}' if am else f'{a}: i64')
            emit(f'fn {name}({", ".join(params)}) -> i64 {{'); funcs+=1; continue
        m=re.match(r'^FUNC\s+([A-Za-z_]\w*)\s*\((.*?)\)\s*(?:->\s*(\w+))?\s*\{\s*$',line,re.I)
        if m:
            name,args,ret=m.groups(); params=[]
            for a in split_top(args):
                if not a: continue
                am=re.match(r'^([A-Za-z_]\w*)\s*:\s*(.+)$',a)
                params.append(f'{am.group(1)}: {am.group(2)}' if am else f'{a}: i64')
            emit(f'fn {name}({", ".join(params)}) -> i64 {{'); funcs+=1; continue
        # aggregate declarations specialized by Milestone 20 generic-struct expansion
        m=re.match(r'^([A-Za-z_]\w*_[A-Za-z0-9_]+)\s+([A-Za-z_]\w*)\s*=\s*(\{.*\})\s*;?$',line)
        if m and m.group(1).lower() not in ('int','i64'):
            ty,n,v=m.groups(); emit(f'let {n}: {ty} = {v};'); continue
        # declarations
        m=re.match(r'^int\s+([A-Za-z_]\w*)\s*\[\s*\]\s*=\s*\[(.*?)\]\s*;?$',line,re.I)
        if m:
            n,vals=m.groups(); items=split_top(vals); arrays.add(n); emit(f'let mut {n}: slice_i64 = slice_i64({len(items)});')
            for idx,v in enumerate(items):
                tmp+=1; emit(f'let mut __seaphire_tmp{tmp}: i64 = slice_set({n}, {idx}, {ex(v)});')
            continue
        m=re.match(r'^int\s+([A-Za-z_]\w*)\s*\[\s*(\d+)\s*\]\s*;?$',line,re.I)
        if m:
            n,z=m.groups(); arrays.add(n); emit(f'let mut {n}: slice_i64 = slice_i64({z});'); continue
        m=re.match(r'^int\s+([A-Za-z_]\w*)\s*(?:=\s*(.+))?;?$',line,re.I)
        if m:
            n,v=m.groups(); emit(f'let mut {n}: i64 = {ex(v) if v else "0"};'); continue
        m=re.match(r'^([A-Za-z_]\w*)\s*\[\s*([^\]]+)\s*\]\s*=\s*(.+?);?$',line)
        if m:
            n,idx,v=m.groups(); tmp+=1; emit(f'let mut __seaphire_tmp{tmp}: i64 = slice_set({n}, {ex(idx)}, {ex(v.rstrip(";"))});'); continue
        if re.match(r'^\}\s+ELSE\s*\{\s*$', line, re.I): emit('} else {'); continue
        m=re.match(r'^MATCH\s+(.+)\s*\{\s*$',line,re.I)
        if m:
            match_stack.append({'expr':ex(m.group(1)),'open':False,'cases':0,'variants':[],'has_default':False}); continue
        m=re.match(r'^CASE\s+([A-Za-z_]\w*)\s*(?:AS\s+([A-Za-z_]\w*))?\s*:\s*$',line,re.I)
        if m and match_stack:
            variant,binding=m.groups()
            if variant not in enums: raise ValueError('unknown enum variant: '+variant)
            st=match_stack[-1]
            cond=f'({st["expr"]} - ({st["expr"]} / 1000000) * 1000000) == {enums[variant]}'
            if st['open']: emit(f'}} else {{\nif {cond} {{')
            else: emit(f'if {cond} {{')
            st['open']=True; st['cases'] += 1; st['variants'].append(variant)
            if binding and payload.get(variant):
                internal=f'__seaphire_payload_{st.get("cases",0)}'; active_binding=(binding, internal)
                emit(f'let mut {internal}: i64 = {st["expr"]} / 1000000;')
            else: active_binding=None
            continue
        if re.match(r'^DEFAULT\s*:\s*$',line,re.I) and match_stack:
            active_binding=None; st=match_stack[-1]
            if st['open']: emit('} else {')
            else: emit('{')
            st['open']=True; st['has_default']=True; continue
        if line=='}':
            active_binding=None
            if match_stack:
                st=match_stack.pop(); match_exhaustive(list(enums.keys()), st['variants'], st['has_default'])
                if st['open']:
                    emit('}')
                    for _ in range(max(0, st.get('cases',0)-1)): emit('}')
                else: emit('}')
            else: emit('}')
            continue
        m=re.match(r'^IF\s+(.+)\s*\{\s*$',line,re.I)
        if m: emit(f'if {ex(m.group(1))} {{'); continue
        m=re.match(r'^ELIF\s+(.+)\s*\{\s*$',line,re.I)
        if m: emit(f'}} else if {ex(m.group(1))} {{'); continue
        if re.match(r'^ELSE\s*\{\s*$',line,re.I): emit('} else {'); continue
        m=re.match(r'^LOOP\s+(.+)\s*\{\s*$',line,re.I)
        if m: emit(f'while {ex(m.group(1))} {{'); continue
        m=re.match(r'^(MOV|ADD|SUB|MUL|DIV)\s+(.+)$',line,re.I)
        if m:
            op,args=m.groups(); aa=split_top(args)
            if len(aa)!=2: raise ValueError(op+' expects two operands')
            a,b=map(ex,aa); sym={'MOV':'=','ADD':'+','SUB':'-','MUL':'*','DIV':'/'}[op.upper()]
            emit(f'{a} = {b};' if op.upper()=='MOV' else f'{a} = {a} {sym} {b};'); continue
        m=re.match(r'^(PRINT|PRINT_COOL)\s+(.+)$',line,re.I)
        if m: emit(f'println {ex(m.group(2))};'); continue
        m=re.match(r'^RET(?:URN)?(?:\s+(.+))?$',line,re.I)
        if m: emit(f'return {ex(m.group(1) or "0")};'); continue
        m=re.match(r'^([A-Za-z_]\w*)\s*=\s*(.+);$',line)
        if m: emit(f'{m.group(1)} = {ex(m.group(2))};'); continue
        if re.match(r'^[A-Za-z_]\w*\s*\(.*\)\s*;?$',line):
            tmp+=1; emit(f'let mut __seaphire_tmp{tmp}: i64 = {ex(line.rstrip(";"))};'); continue
        raise ValueError('unsupported Seaphire v2 statement: '+line)
    if match_stack: raise ValueError('unterminated MATCH')
    if funcs==0: raise ValueError('no FUNC/function declarations found')
    return '\n'.join(out)+'\n'

if __name__=='__main__':
    if len(sys.argv)!=3: print('usage: seaphire_v2.py input output',file=sys.stderr); sys.exit(2)
    try:
        with open(sys.argv[1],encoding='utf-8') as f: src=f.read()
        with open(sys.argv[2],'w',encoding='utf-8') as f: f.write(translate(src))
    except Exception as e:
        print('seaphire v2 frontend:',e,file=sys.stderr); sys.exit(1)
