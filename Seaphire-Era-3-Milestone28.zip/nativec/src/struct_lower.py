#!/usr/bin/env python3
"""Milestone 14 aggregate-struct lowering.

This pass keeps the existing small native core intentionally simple while giving
Seaphire real aggregate layout semantics at the source boundary. Structs are
laid out as 8-byte machine-word fields, with nested structs flattened in place.
Owning slice_i64/box_i64 fields are stored as raw pointers in heap-struct backing
storage and reconstructed with typed intrinsics before use. The generated code
keeps ownership explicit and frees owned aggregate members exactly once.
"""
import re, sys

src = open(sys.argv[1], encoding='utf-8').read()

# ---------- type/layout model ----------
structs = {}

# field: (name, type)
field_re = re.compile(r'([A-Za-z_]\w*)\s*:\s*([A-Za-z_]\w*)')
for m in re.finditer(r'\bstruct\s+([A-Za-z_]\w*)\s*\{([^{}]*)\}', src, re.S):
    name, body = m.group(1), m.group(2)
    fields = field_re.findall(body)
    if not fields:
        raise SystemExit(f'seaphirec: struct {name}: empty struct')
    structs[name] = fields

if len(structs) != len(set(structs)):
    raise SystemExit('seaphirec: duplicate struct declaration')

PRIMS = {'i64', 'slice_i64', 'box_i64'}

def layout(name, visiting=None):
    visiting = set() if visiting is None else set(visiting)
    if name in visiting:
        raise SystemExit(f'seaphirec: recursive struct layout is not supported: {name}')
    visiting.add(name)
    out = []
    for fname, ty in structs[name]:
        if ty in PRIMS:
            out.append((fname, ty))
        elif ty in structs:
            for subname, subty in layout(ty, visiting):
                out.append((f'{fname}__{subname}', subty))
        else:
            raise SystemExit(f'seaphirec: unknown field type {ty} in {name}')
    return out

layouts = {n: layout(n) for n in structs}

# Every field occupies one machine word in this first ABI. Alignment is therefore 8.
# Keep explicit metadata in the generated source for diagnostics/documentation.
def layout_comment():
    lines = ['// SEAPHIRE_AGGREGATE_LAYOUTS: all fields 8-byte aligned; size = slots * 8 bytes.']
    for n, fs in layouts.items():
        lines.append(f'// layout {n}: size={len(fs)*8} align=8 slots=' + ','.join(f'{f}:{t}' for f,t in fs))
    return '\n'.join(lines) + '\n'

# ---------- expression helpers ----------
def split_top(s, sep=','):
    out=[]; start=0; depth=0; quote=False; esc=False
    for i,ch in enumerate(s):
        if quote:
            if esc: esc=False
            elif ch=='\\': esc=True
            elif ch=='"': quote=False
            continue
        if ch=='"': quote=True; continue
        if ch in '{([': depth += 1
        elif ch in '})]': depth -= 1
        elif ch==sep and depth==0:
            out.append(s[start:i].strip()); start=i+1
    out.append(s[start:].strip())
    return [x for x in out if x]

def parse_literal(body):
    d={}
    for item in split_top(body):
        if ':' not in item: raise SystemExit('seaphirec: malformed struct literal field')
        k,v=item.split(':',1); k=k.strip(); v=v.strip()
        if k in d: raise SystemExit(f'seaphirec: duplicate struct literal field {k}')
        d[k]=v
    return d

def parse_expr_struct(expr, ty):
    expr=expr.strip()
    if expr.startswith('{') and expr.endswith('}'):
        return parse_literal(expr[1:-1])
    return None

def flatten_literal(ty, lit, prefix=''):
    if ty not in structs: raise SystemExit(f'seaphirec: unknown aggregate type {ty}')
    expected={f for f,_ in structs[ty]}
    if set(lit)!=expected:
        raise SystemExit(f'seaphirec: {ty} literal fields mismatch; expected {sorted(expected)}')
    result=[]
    for fname, fty in structs[ty]:
        v=lit[fname]
        path=f'{prefix}__{fname}' if prefix else fname
        if fty in structs:
            sub=parse_expr_struct(v, fty)
            if sub is None:
                # permit move of an existing aggregate; handled separately
                result.append((path, fty, v))
            else:
                result.extend(flatten_literal(fty, sub, path))
        else:
            result.append((path, fty, v))
    return result

# Remove declarations but keep their exact source text available to subsequent rewrites.
src = re.sub(r'\bstruct\s+[A-Za-z_]\w*\s*\{[^{}]*\}\s*', '', src)

# ---------- aggregate variable bookkeeping ----------
agg_vars = {}          # source name -> struct type
heap_vars = {}         # source name -> (backing slice local, struct type)
field_info = {}        # (var, field path) -> (flat local, type)

# Generate a unique primitive local for a flattened field.
def flat_name(var, path):
    return f'{var}__{path}'

def typed_field_decl(mut, var, path, ty, value):
    return f'let {mut}{flat_name(var,path)}: {ty} = {value};'

# stack aggregate literals and moves; repeat to handle declarations in either order.
for ty, fs in structs.items():
    pat = re.compile(r'let\s+(mut\s+)?(\w+)\s*:\s*'+re.escape(ty)+r'\s*=\s*(\{.*?\})\s*;', re.S)
    def repl(m, ty=ty):
        mut='mut ' if m.group(1) else ''; var=m.group(2); lit=parse_expr_struct(m.group(3),ty)
        if lit is None: raise SystemExit(f'seaphirec: malformed {ty} literal')
        agg_vars[var]=ty
        parts=flatten_literal(ty,lit)
        out=[]
        for path, fty, value in parts:
            if fty in structs:
                raise SystemExit('seaphirec: aggregate move initializers require a named source; nested literals are supported only for concrete fields')
            out.append(typed_field_decl(mut,var,path,fty,value))
            field_info[(var,path)]=(flat_name(var,path),fty)
        return '\n'.join(out)
    src=pat.sub(repl,src)

# Heap aggregate literal: one backing slice with one 8-byte slot per flattened field.
for ty in structs:
    pat = re.compile(r'let\s+(mut\s+)?(\w+)\s*:\s*'+re.escape(ty)+r'\s*=\s*box\s+'+re.escape(ty)+r'\s*\{(.*?)\}\s*;', re.S)
    def repl(m, ty=ty):
        mut='mut ' if m.group(1) else ''; var=m.group(2); lit=parse_literal(m.group(3))
        agg_vars[var]=ty; hv=var+'__heap'; heap_vars[var]=(hv,ty)
        parts=flatten_literal(ty,lit)
        out=[f'let {mut}{hv}: slice_i64 = slice_i64({len(layouts[ty])});']
        for i,(path,fty,value) in enumerate(parts):
            if fty in structs: raise SystemExit('seaphirec: nested aggregate heap initialization must use a nested literal')
            if fty in ('slice_i64','box_i64'):
                raw=f'{fty.replace("_i64", "")}_raw({value})'
                out.append(f'let __seaphire_init_{var}_{i}: i64 = slice_set({hv}, {i}, {raw});')
            else:
                out.append(f'let __seaphire_init_{var}_{i}: i64 = slice_set({hv}, {i}, {value});')
            field_info[(var,path)]=(i,fty)
        return '\n'.join(out)
    src=pat.sub(repl,src)

# Stack aggregate moves: fieldwise ownership transfer. Heap aggregate moves transfer backing slice.
for ty in structs:
    pat = re.compile(r'let\s+(mut\s+)?(\w+)\s*:\s*'+re.escape(ty)+r'\s*=\s*move\s+(\w+)\s*;')
    def repl(m, ty=ty):
        mut='mut ' if m.group(1) else ''; dst,srcv=m.group(2),m.group(3)
        if srcv in heap_vars:
            hv=srcv+'__heap'; dhv=dst+'__heap'; heap_vars[dst]=(dhv,ty)
            return f'let {mut}{dhv}: slice_i64 = move_slice({hv});\n// SEAPHIRE_MOVED_HEAP:{srcv}'
        if srcv not in agg_vars:
            raise SystemExit(f"seaphirec: move of unknown aggregate '{srcv}'")
        agg_vars[dst]=ty
        out=[]
        for path,fty in layouts[ty]:
            out.append(f'let {mut}{flat_name(dst,path)}: {fty} = {flat_name(srcv,path)};')
            field_info[(dst,path)]=(flat_name(dst,path),fty)
        out.append(f'// SEAPHIRE_MOVED:{srcv}')
        return '\n'.join(out)
    src=pat.sub(repl,src)

# Owning heap-field reads are moves, not copies. Clear the aggregate slot so the
# extracted owner is dropped independently and the aggregate drop sees a null slot.
for var,(hv,ty) in list(heap_vars.items()):
    for i,(path,fty) in enumerate(layouts[ty]):
        if fty not in ("slice_i64", "box_i64"):
            continue
        dotted=path.replace('__','.')
        conv=f'{fty.replace("_i64", "")}_from_raw(slice_at({hv}, {i}))'
        pat=re.compile(r'let\s+(mut\s+)?(\w+)\s*:\s*'+re.escape(fty)+r'\s*=\s*'+re.escape(var)+r'\.'+re.escape(dotted)+r'\s*;')
        def move_field(m,conv=conv,hv=hv,i=i,var=var,path=path,fty=fty):
            mut='mut ' if m.group(1) else ''; dst=m.group(2)
            rawzero=f'let __seaphire_take_{var}_{path}: i64 = slice_set({hv}, {i}, 0);'
            return f'let {mut}{dst}: {fty} = {conv};\n{rawzero}'
        src=pat.sub(move_field,src)

# Heap field access/assignment. Nested paths are already flattened in layout metadata.
for var,(hv,ty) in list(heap_vars.items()):
    for i,(path,fty) in enumerate(layouts[ty]):
        q=re.escape(var)+r'\.'+re.escape(path.replace('__','.'))
        # assignment first so it cannot be consumed by read rewrite
        if fty in ('slice_i64','box_i64'):
            # Owning replacement drops the previous member before storing the new pointer.
            def aset(m, hv=hv,i=i,fty=fty,var=var,path=path):
                raw=f'{fty.replace("_i64", "")}_raw({m.group(1).strip()})'
                free=f'let __seaphire_field_drop_{var}_{path}: i64 = free_{fty.replace("_i64", "")}({fty.replace("_i64", "")}_from_raw(slice_at({hv}, {i})));'
                return f'let __seaphire_field_set_{var}_{path}: i64 = 0;\n{free}let __seaphire_field_store_{var}_{path}: i64 = slice_set({hv}, {i}, {raw});'
            src=re.sub(q+r'\s*=\s*([^;]+);',aset,src)
            conv=f'{fty.replace("_i64", "")}_from_raw(slice_at({hv}, {i}))'
            src=re.sub(q+r'\b',conv,src)
        else:
            src=re.sub(q+r'\s*=\s*([^;]+);',lambda m,i=i,hv=hv,var=var,path=path:f'let __seaphire_field_set_{var}_{path}: i64 = slice_set({hv}, {i}, {m.group(1)});',src)
            src=re.sub(q+r'\b',f'slice_at({hv}, {i})',src)

# Stack field access and assignment. Field paths use a flattened local name.
for var,ty in list(agg_vars.items()):
    if var in heap_vars: continue
    for path,fty in layouts[ty]:
        dotted=path.replace('__','.')
        src=re.sub(r'\b'+re.escape(var)+r'\.'+re.escape(dotted)+r'\s*=\s*([^;]+);',lambda m,var=var,path=path:f'{flat_name(var,path)} = {m.group(1)};',src)
        src=re.sub(r'\b'+re.escape(var)+r'\.'+re.escape(dotted)+r'\b',flat_name(var,path),src)

# Borrowing a stack aggregate field: &p.x -> &p__x; heap fields use a temporary pointer slot.
for var,ty in list(agg_vars.items()):
    for path,fty in layouts[ty]:
        dotted=path.replace('__','.')
        if var in heap_vars:
            hv,_=heap_vars[var]; idx=layouts[ty].index((path,fty))
            # Only scalar fields can be borrowed by the existing reference backend.
            if fty in ('i64',):
                src=re.sub(r'&mut\s+'+re.escape(var)+r'\.'+re.escape(dotted)+r'\b',f'&mut __seaphire_ref_{var}_{idx}',src)
                src=re.sub(r'&'+re.escape(var)+r'\.'+re.escape(dotted)+r'\b',f'&__seaphire_ref_{var}_{idx}',src)
        else:
            src=re.sub(r'&mut\s+'+re.escape(var)+r'\.'+re.escape(dotted)+r'\b',f'&mut {flat_name(var,path)}',src)
            src=re.sub(r'&'+re.escape(var)+r'\.'+re.escape(dotted)+r'\b',f'&{flat_name(var,path)}',src)

# Remove remaining aggregate declarations: anything not lowered is a hard error.
for ty in structs:
    if re.search(r':\s*'+re.escape(ty)+r'\b',src):
        raise SystemExit(f'seaphirec: unsupported aggregate use of {ty}')

# Static use-after-move for stack and heap aggregates.
for m in re.finditer(r'// SEAPHIRE_MOVED:(\w+)\s*\n',src):
    name=m.group(1); tail=src[m.end():]
    if re.search(r'\b'+re.escape(name)+r'__\w+\b',tail):
        raise SystemExit(f"seaphirec: use of moved struct '{name}'")
for m in re.finditer(r'// SEAPHIRE_MOVED_HEAP:(\w+)\s*\n',src):
    name=m.group(1); tail=src[m.end():]
    if re.search(r'\b'+re.escape(name)+r'__heap\b',tail):
        raise SystemExit(f"seaphirec: use of moved heap struct '{name}'")
src=re.sub(r'// SEAPHIRE_MOVED(?:_HEAP)?:\w+\s*\n','',src)

# Generate raw pointer conversion intrinsics as tiny declarations understood by the native core.
# The native core's typed model treats them as no-op pointer reinterpretations.
helper_names='''
// SEAPHIRE_AGGREGATE_RAW_INTRINSICS: handled by seaphirec-native core
'''

# Automatic drop of heap aggregate members. The outer backing slice owns member pointers.
def process_fn(m):
    name,args,body=m.group(1),m.group(2),m.group(3)
    owned=[]
    for var,(hv,ty) in heap_vars.items():
        if re.search(r'\blet\s+(?:mut\s+)?'+re.escape(hv)+r'\s*:\s*slice_i64\s*=\s*slice_i64\(',body):
            owned.append((hv,ty))
        if re.search(r'\b'+re.escape(hv)+r'\b',body) and not any(x[0]==hv for x in owned):
            owned.append((hv,ty))
    # Remove moved source owners if the move occurs in this function.
    for hv,_ in list(owned):
        if re.search(r'move_slice\('+re.escape(hv)+r'\)',body):
            owned=[x for x in owned if x[0]!=hv]
    frees=[]
    for hv,ty in owned:
        for i,(_,fty) in enumerate(layouts[ty]):
            if fty in ('slice_i64','box_i64'):
                free=f'free_{fty.replace("_i64", "")}({fty.replace("_i64", "")}_from_raw(slice_at({hv}, {i})));\n'
                frees.append(free)
        frees.append(f'let __seaphire_drop_{hv}: i64 = free_slice({hv});\n')
    def ret(mm):
        expr=mm.group(1).strip()
        tmp=f'__seaphire_ret_{name}'
        return f'let {tmp}: i64 = {expr};\n'+''.join(frees)+f'return {tmp};'
    body=re.sub(r'\breturn\s+([^;]+);',ret,body)
    if frees and not re.search(r'\breturn\s+[^;]+;\s*$',body.strip()):
        body += ''.join(frees)
    return f'fn {name}({args}) {{\n{body}\n}}'

src=re.sub(r'\bfn\s+(\w+)\s*\(([^)]*)\)\s*\{(.*?)\n\}',process_fn,src,flags=re.S)
src=layout_comment()+helper_names+src
open(sys.argv[2],'w',encoding='utf-8').write(src)
