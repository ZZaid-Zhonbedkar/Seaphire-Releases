mod lexer;
mod ast;
mod parser;
mod runtime;
mod error;
mod safety;
mod kernel_codegen;

use std::{env,fs,process::ExitCode};
use std::path::PathBuf;

fn main() -> ExitCode {
    let mut args = env::args().skip(1);
    let first = match args.next() { Some(p) => p, None => { eprintln!("usage: seaphirec <file.inu> | seaphirec --kernel-x86_64 <out-dir>"); return ExitCode::from(2); } };
    if first == "--kernel-x86_64" {
        let out = PathBuf::from(args.next().unwrap_or_else(|| "build/kernel".into()));
        return match kernel_codegen::emit_x86_64_kernel(&out) { Ok(()) => { println!("kernel ABI scaffold emitted to {}", out.display()); ExitCode::SUCCESS }, Err(e) => { eprintln!("{e}"); ExitCode::from(1) } };
    }
    let path = first;
    let src = match fs::read_to_string(&path) {
        Ok(s) => s,
        Err(e) => { eprintln!("error: cannot read {path}: {e}"); return ExitCode::from(2); }
    };
    match lexer::lex(&src).and_then(|t| parser::parse(&t)).and_then(|p| { safety::check(&p)?; runtime::run(&p) }) {
        Ok(code) => ExitCode::from(code.clamp(0,255) as u8),
        Err(e) => { eprintln!("{e}"); ExitCode::from(1) }
    }
}
