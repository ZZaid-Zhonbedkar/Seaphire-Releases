use std::collections::HashMap;
use crate::{ast::*, error::{Error, Result}};

#[derive(Clone)] struct Binding { ty: Type, mutable: bool, moved: bool, borrowed: usize, mut_borrowed: bool }

/// Era 2 Delta safety pass. This is intentionally conservative:
/// - immutable by default
/// - assignments require `mut`
/// - a value cannot be used after it is moved
/// - mutable borrows exclude all other borrows
/// - ordinary borrows exclude mutation while alive
/// - types must match exactly at the source boundary
pub fn check(functions: &[Function]) -> Result<()> {
    let mut names: HashMap<String, Type> = HashMap::new();
    for f in functions {
        if names.insert(f.name.clone(), f.ret.clone()).is_some() {
            return Err(Error::new(1, 1, format!("duplicate function `{}`", f.name)));
        }
    }
    for f in functions { check_fn(f, &names)?; }
    Ok(())
}

fn check_fn(f: &Function, funcs: &HashMap<String, Type>) -> Result<()> {
    let mut env = HashMap::new();
    for (n, t) in &f.params {
        if env.insert(n.clone(), Binding { ty: t.clone(), mutable: false, moved: false, borrowed: 0, mut_borrowed: false }).is_some() {
            return Err(Error::new(1,1, format!("duplicate parameter `{n}`")));
        }
    }
    for s in &f.body { check_stmt(s, &mut env, funcs)?; }
    Ok(())
}

fn check_stmt(s: &Stmt, env: &mut HashMap<String, Binding>, funcs: &HashMap<String, Type>) -> Result<()> {
    match s {
        Stmt::Let { name, ty, mutable, value } => {
            if env.contains_key(name) { return Err(Error::new(1,1, format!("binding `{name}` already exists in this scope"))); }
            let got = expr_type(value, env, funcs)?;
            if !same_type(ty, &got) { return Err(Error::new(1,1, format!("type mismatch: `{name}` expects {:?}, got {:?}", ty, got))); }
            env.insert(name.clone(), Binding { ty: ty.clone(), mutable: *mutable, moved: false, borrowed: 0, mut_borrowed: false });
        }
        Stmt::Assign { name, value } => {
            let got = expr_type(value, env, funcs)?;
            let b = env.get_mut(name).ok_or_else(|| Error::new(1,1, format!("unknown variable `{name}`")))?;
            if !b.mutable { return Err(Error::new(1,1, format!("cannot assign to immutable `{name}`"))); }
            if b.moved { return Err(Error::new(1,1, format!("use of moved value `{name}`"))); }
            if b.borrowed != 0 || b.mut_borrowed { return Err(Error::new(1,1, format!("cannot mutate `{name}` while it is borrowed"))); }
            if !same_type(&b.ty, &got) { return Err(Error::new(1,1, format!("type mismatch in assignment to `{name}`"))); }
        }
        Stmt::Expr(e) | Stmt::Print(e, _) => { expr_type(e, env, funcs)?; }
        Stmt::Return(Some(e)) => { expr_type(e, env, funcs)?; }
        Stmt::Return(None) => {}
        Stmt::If { condition, then_block, else_block } => {
            if !matches!(expr_type(condition, env, funcs)?, Type::Bool) { return Err(Error::new(1,1, "if condition must be bool")); }
            for x in then_block { check_stmt(x, env, funcs)?; }
            for x in else_block { check_stmt(x, env, funcs)?; }
        }
        Stmt::While { condition, body } => {
            if !matches!(expr_type(condition, env, funcs)?, Type::Bool) { return Err(Error::new(1,1, "while condition must be bool")); }
            for x in body { check_stmt(x, env, funcs)?; }
        }
    }
    Ok(())
}

fn expr_type(e: &Expr, env: &mut HashMap<String, Binding>, funcs: &HashMap<String, Type>) -> Result<Type> {
    match e {
        Expr::Int(_) => Ok(Type::I64), Expr::Float(_) => Ok(Type::F64), Expr::Bool(_) => Ok(Type::Bool), Expr::Str(_) => Ok(Type::Str),
        Expr::Var(n) => {
            let b = env.get(n).ok_or_else(|| Error::new(1,1, format!("unknown variable `{n}`")))?;
            if b.moved { return Err(Error::new(1,1, format!("use of moved value `{n}`"))); }
            Ok(b.ty.clone())
        }
        Expr::Neg(x) => match expr_type(x, env, funcs)? { Type::I32|Type::I64|Type::U32|Type::U64|Type::F64 => Ok(expr_type(x, env, funcs)?), _ => Err(Error::new(1,1,"unary - requires a numeric value")) },
        Expr::Binary(a, op, b) => {
            let ta = expr_type(a, env, funcs)?; let tb = expr_type(b, env, funcs)?;
            match op {
                BinOp::Eq|BinOp::Ne|BinOp::Lt|BinOp::Le|BinOp::Gt|BinOp::Ge|BinOp::And|BinOp::Or => Ok(Type::Bool),
                _ if same_type(&ta, &tb) && matches!(ta, Type::I32|Type::I64|Type::U32|Type::U64|Type::F64) => Ok(ta),
                BinOp::Add if ta == Type::Str && tb == Type::Str => Ok(Type::Str),
                _ => Err(Error::new(1,1,"invalid operands")),
            }
        }
        Expr::Call(n, _) => funcs.get(n).cloned().ok_or_else(|| Error::new(1,1, format!("unknown function `{n}`"))),
    }
}

fn same_type(a: &Type, b: &Type) -> bool { a == b }
