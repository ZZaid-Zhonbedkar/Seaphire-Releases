//! Minimal freestanding x86_64 backend contract.
//! Era 2 Delta OS currently emits a fixed ABI shim for the kernel entrypoint.
//! The language frontend remains the source of truth; this module deliberately
//! refuses to claim general-purpose machine-code generation until type/layout
//! lowering is complete.

use std::{fs, path::Path};
use crate::error::{Error, Result};

pub fn emit_x86_64_kernel(out: &Path) -> Result<()> {
    fs::create_dir_all(out).map_err(|e| Error::new(1,1,format!("cannot create kernel output: {e}")))?;
    fs::write(out.join("seaphire_kernel_entry.S"), r#".section .text
.global _start
.type _start,@function
_start:
    cli
    xor %rbp,%rbp
    call seaphire_kernel_main
1:  hlt
    jmp 1b

.global seaphire_kernel_main
.type seaphire_kernel_main,@function
seaphire_kernel_main:
    mov $0xb8000,%rdi
    mov $0x0f48,%ax
    mov %ax,(%rdi)
    mov $0x0f69,%ax
    mov %ax,2(%rdi)
    mov $0x0f21,%ax
    mov %ax,4(%rdi)
    ret
"#).map_err(|e| Error::new(1,1,format!("cannot write kernel entry: {e}")))?;
    fs::write(out.join("kernel.ld"), r#"ENTRY(_start)
SECTIONS {
  . = 1M;
  .text : ALIGN(4K) { *(.text*) }
  .rodata : ALIGN(4K) { *(.rodata*) }
  .data : ALIGN(4K) { *(.data*) }
  .bss : ALIGN(4K) { *(COMMON) *(.bss*) }
}
"#).map_err(|e| Error::new(1,1,format!("cannot write linker script: {e}")))?;
    Ok(())
}
