#[derive(Debug,Clone,PartialEq)] pub enum Type { I32,I64,U32,U64,F64,Bool,Str,Unit }
#[derive(Debug,Clone,PartialEq)] pub enum BinOp { Add,Sub,Mul,Div,Eq,Ne,Lt,Le,Gt,Ge,And,Or }
#[derive(Debug,Clone,PartialEq)] pub enum Expr { Int(i64),Float(f64),Bool(bool),Str(String),Var(String),Binary(Box<Expr>,BinOp,Box<Expr>),Neg(Box<Expr>),Call(String,Vec<Expr>) }
#[derive(Debug,Clone)] pub enum Stmt { Let{name:String,ty:Type,mutable:bool,value:Expr},Assign{name:String,value:Expr},Expr(Expr),Print(Expr,bool),If{condition:Expr,then_block:Vec<Stmt>,else_block:Vec<Stmt>},While{condition:Expr,body:Vec<Stmt>},Return(Option<Expr>) }
#[derive(Debug,Clone)] pub struct Function { pub name:String,pub params:Vec<(String,Type)>,pub ret:Type,pub body:Vec<Stmt> }
