use crate::error::{Error,Result};
#[derive(Debug,Clone,PartialEq)] pub enum TokenKind { Ident(String),Int(i64),Float(f64),Str(String),Let,Mut,Fn,If,Else,While,Return,True,False,Print,Println,I32,I64,U32,U64,F64,Bool,StrTy,Unit,Plus,Minus,Star,Slash,Eq,EqEq,Ne,Lt,Le,Gt,Ge,And,Or,LParen,RParen,LBrace,RBrace,Colon,Comma,Arrow,Semicolon,Eof }
#[derive(Debug,Clone)] pub struct Token { pub kind:TokenKind,pub line:usize,pub col:usize }
pub fn lex(s:&str)->Result<Vec<Token>>{
 let b=s.as_bytes();let mut i=0;let mut line=1;let mut col=1;let mut out=Vec::new();
 while i<b.len(){let c=b[i] as char;
  if c.is_whitespace(){if c=='\n'{line+=1;col=1}else{col+=1};i+=1;continue}
  if c=='/'&&i+1<b.len()&&b[i+1] as char=='/'{while i<b.len()&&b[i] as char!='\n'{i+=1;col+=1};continue}
  let l=line;let cc=col;
  if c.is_ascii_alphabetic()||c=='_'{let st=i;while i<b.len()&&((b[i] as char).is_ascii_alphanumeric()||b[i] as char=='_'){i+=1;col+=1}let w=&s[st..i];let k=match w{"let"=>TokenKind::Let,"mut"=>TokenKind::Mut,"fn"=>TokenKind::Fn,"if"=>TokenKind::If,"else"=>TokenKind::Else,"while"=>TokenKind::While,"return"=>TokenKind::Return,"true"=>TokenKind::True,"false"=>TokenKind::False,"print"=>TokenKind::Print,"println"=>TokenKind::Println,"i32"=>TokenKind::I32,"i64"=>TokenKind::I64,"u32"=>TokenKind::U32,"u64"=>TokenKind::U64,"f64"=>TokenKind::F64,"bool"=>TokenKind::Bool,"str"=>TokenKind::StrTy,"unit"=>TokenKind::Unit,_=>TokenKind::Ident(w.into())};out.push(Token{kind:k,line:l,col:cc});continue}
  if c.is_ascii_digit(){let st=i;let mut dot=false;while i<b.len()&&((b[i] as char).is_ascii_digit()||(!dot&&b[i] as char=='.')){if b[i] as char=='.'{dot=true};i+=1;col+=1}let w=&s[st..i];let k=if dot{TokenKind::Float(w.parse().unwrap())}else{TokenKind::Int(w.parse().unwrap())};out.push(Token{kind:k,line:l,col:cc});continue}
  if c=='"'{i+=1;col+=1;let mut v=String::new();while i<b.len()&&b[i] as char!='"'{if b[i] as char=='\\'&&i+1<b.len(){i+=1;col+=1;v.push(match b[i] as char{'n'=>'\n','t'=>'\t','r'=>'\r','"'=>'"','\\'=>'\\',x=>x});}else{v.push(b[i] as char)}i+=1;col+=1}if i>=b.len(){return Err(Error::new(l,cc,"unterminated string"))}i+=1;col+=1;out.push(Token{kind:TokenKind::Str(v),line:l,col:cc});continue}
  let two=if i+1<b.len(){&s[i..i+2]}else{""};let k=match two{"=="=>Some(TokenKind::EqEq),"!="=>Some(TokenKind::Ne),"<="=>Some(TokenKind::Le),">="=>Some(TokenKind::Ge),"&&"=>Some(TokenKind::And),"||"=>Some(TokenKind::Or),"->"=>Some(TokenKind::Arrow),_=>None};if let Some(k)=k{i+=2;col+=2;out.push(Token{kind:k,line:l,col:cc});continue}
  let k=match c{'+'=>TokenKind::Plus,'-'=>TokenKind::Minus,'*'=>TokenKind::Star,'/'=>TokenKind::Slash,'='=>TokenKind::Eq,'<'=>TokenKind::Lt,'>'=>TokenKind::Gt,'('=>TokenKind::LParen,')'=>TokenKind::RParen,'{'=>TokenKind::LBrace,'}'=>TokenKind::RBrace,':'=>TokenKind::Colon,','=>TokenKind::Comma,';'=>TokenKind::Semicolon,_=>return Err(Error::new(l,cc,format!("unexpected character {c:?}")))};i+=1;col+=1;out.push(Token{kind:k,line:l,col:cc});
 }
 out.push(Token{kind:TokenKind::Eof,line,col});Ok(out)
}
